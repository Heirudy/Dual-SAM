import argparse
import glob
import os
import re
import shutil
import time

import nibabel as nib
import numpy as np
import SimpleITK as sitk
import torch
from matplotlib import pyplot as plt
from medpy import metric
from scipy.ndimage import zoom
from thop import profile

from tqdm import tqdm
from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip
from PIL import Image

from metrics.metric import Metric
# from networks.efficientunet import UNet
from networks.net_factory import net_factory
from torch.utils.data import DataLoader
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default='../data/ACDC', help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='Kavsir-SEG/Uncertainty_Aware_Mean_Teacher', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='unet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=2,
                    help='output channel of network')
parser.add_argument('--labeled_num', type=int, default=7,
                    help='labeled data')

class testDataset:
    def __init__(self, img_paths, mask_paths,


                 mask_divide=False, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=1024) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size

        # self.bbox_shift = bbox_shift

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        img = Image.open(img_path).convert("RGB")
        # img = tf.imread(img_path)
        mask = Image.open(mask_path).convert("L")

        img = np.asarray(img)
        mask = np.asarray(mask)
        if self.mask_divide:
            mask = mask // self.divide_value
        # sample = {"image": img, "label": mask}
        # if None not in (self.ops_weak, self.ops_strong):
        #         sample = self.transform(sample, self.ops_weak, self.ops_strong)
        # else:
        #         sample = self.transform(sample)
        transform = Compose(
            [
                # ColorJitter(),
                # VerticalFlip(),
                # HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )

        aug_data = transform(image=img,mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        sample = {"image": torch.from_numpy(x), "label": torch.from_numpy(target)}
        # sample = {"image": x, "label": target}
        return sample

def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    asd = metric.binary.asd(pred, gt)
    hd95 = metric.binary.hd95(pred, gt)
    return dice, hd95, asd


def test_single_volume(sampled_batch, net, test_save_path, FLAGS,metric,i):
    # h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    # image = h5f['image'][:]
    # label = h5f['label'][:]
    # prediction = np.zeros_like(label)
    image, target = sampled_batch['image'], sampled_batch['label']
    # for ind in range(image.shape[0]):
    #     slice = image[ind, :, :]
    #     x, y = slice.shape[0], slice.shape[1]
    #     slice = zoom(slice, (256 / x, 256 / y), order=0)
    #     input = torch.from_numpy(slice).unsqueezQe(
    #         0).unsqueeze(0).float().cuda()
    # net.eval()
    input = image.float().cuda()



    with torch.no_grad():

        if FLAGS.model == "unet_urpc":
             out_main,_, _,_ = net(input)
        else:
            out_main = net(input)
        # out = torch.softmax(out_main, dim=1)
        out=out_main
        metric.update(out, target)
        pred = torch.max(out, dim=1)[1]
        # _, axs = plt.subplots(1, 2, figsize=(25, 25))
        # axs[0].imshow(pred.cpu().permute(1, 2, 0).detach().numpy(),cmap='gray')
        # axs[1].imshow(target.cpu().permute(1, 2, 0).detach().numpy(),cmap='gray')
        # plt.subplots_adjust(wspace=0.01, hspace=0)
        # filename = f"./test{i + 1}.png"
        # full_path = os.path.join(test_save_path, filename)
        # plt.savefig(full_path, bbox_inches="tight", dpi=300)

        predname = f"./pred{i + 1}.png"
        pred_path = os.path.join(test_save_path, predname)
        pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
        plt.figure(figsize=(10, 10))
        plt.imshow(pred_image, cmap='gray', interpolation='none')
        plt.axis('off')
        plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        plt.close('all')

        # out = torch.argmax(torch.softmax(
        #     out_main, dim=1), dim=1).squeeze(0)
        # out = out.cpu().detach().numpy()
        # pred = zoom(out, (x / 256, y / 256), order=0)
        # prediction[ind] = pred
    #
    # first_metric = calculate_metric_percase(prediction == 1, label == 1)
    # second_metric = calculate_metric_percase(prediction == 2, label == 2)
    # third_metric = calculate_metric_percase(prediction == 3, label == 3)
    #
    # img_itk = sitk.GetImageFromArray(image.astype(np.float32))
    # img_itk.SetSpacing((1, 1, 10))
    # prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
    # prd_itk.SetSpacing((1, 1, 10))
    # lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
    # lab_itk.SetSpacing((1, 1, 10))
    # sitk.WriteImage(prd_itk, test_save_path + case + "_pred.nii.gz")
    # sitk.WriteImage(img_itk, test_save_path + case + "_img.nii.gz")
    # sitk.WriteImage(lab_itk, test_save_path + case + "_gt.nii.gz")
    # return first_metric, second_metric, third_metric


def Inference(FLAGS):
    # with open(FLAGS.root_path + '/test.list', 'r') as f:
    #     image_list = f.readlines()
    # image_list = sorted([item.replace('\n', '').split(".")[0]
    #                      for item in image_list])
    # snapshot_path = "../model/{}_{}_labeled/{}".format(
    #     FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
    test_save_path = "../outputs/{}".format(
         FLAGS.exp)
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)

    # img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\FIVES\test\Original"
    # mask_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # prompt_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # img_path = r"D:\2024\ssr\DATA\STARE\Images"
    # mask_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # prompt_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image\CXR_4"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # prompt_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"

    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\image"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\images"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\test\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path =r"D:\2024\ssr\DATA\CXR\test\mask"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"

    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    # image = h5f['image'][:]
    # label = h5f['label'][:]
    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)

    net = net_factory(net_type=FLAGS.model, in_chns=3,
                      class_num=FLAGS.num_classes)
    save_mode_path =r"D:\2024\ssr\SSL4MIS-master\model\Kavsir-SEG\Uncertainty_Aware_Mean_Teacher_70_labeled\unet\epoch_100.pth"
    # save_mode_path = os.path.join(
    #     snapshot_path, '{}_best_model.pth'.format(FLAGS.model))
    net.load_state_dict(torch.load(save_mode_path))
    print("init weight from {}".format(save_mode_path))
    net.eval()



    metric = Metric(num_classes=2)
    for i, sample in enumerate(dataloader):
        test_single_volume(sample, net, test_save_path, FLAGS, metric, i)
    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))
    # first_total = 0.0
    # second_total = 0.0
    # third_total = 0.0
    # for case in tqdm(image_list):
    #     first_metric, second_metric, third_metric = test_single_volume(
    #         case, net, test_save_path, FLAGS)
    #     first_total += np.asarray(first_metric)
    #     second_total += np.asarray(second_metric)
    #     third_total += np.asarray(third_metric)
    # avg_metric = [first_total / len(image_list), second_total /
    #               len(image_list), third_total / len(image_list)]
    # return avg_metric


if __name__ == '__main__':
    FLAGS = parser.parse_args()
    Inference(FLAGS)
    # metric = Inference(FLAGS)
    # print(metric)
    # print((metric[0]+metric[1]+metric[2])/3)
