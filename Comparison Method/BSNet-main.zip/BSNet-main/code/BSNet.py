import glob
import os
import cv2
import random
import numpy as np
from torch.utils.data import Dataset, DataLoader

import itertools
from scipy import ndimage
from torch.utils.data.sampler import Sampler
import random
import time
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.nn import BCEWithLogitsLoss
from torch.nn.modules.loss import CrossEntropyLoss
from torchvision import transforms
from tqdm import tqdm

from metrics.metric import Metric
from models import *
from dataset import *
from torchsummary import summary
from utils import *
from efficientNet import *


from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip


os.environ["CUDA_VISIBLE_DEVICES"] = "0"


class SegDataset:
    def __init__(self, img_paths, mask_paths,
                 mask_divide=False, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=512) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size
        # self.bbox_shift = bbox_shift

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        img = Image.open(img_path).convert("RGB")
        # img = tf.imread(img_path)
        mask = Image.open(mask_path).convert("L")

        img = np.asarray(img)
        mask = np.asarray(mask)
        if self.mask_divide:
            mask = mask // self.divide_value

        transform = Compose(
            [
                ColorJitter(),
                VerticalFlip(),
                HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )
        aug_data = transform(image=img, mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        sample = {"image": torch.from_numpy(x), "label": torch.from_numpy(target)}

        return sample


def iterate_once(iterable):
    return np.random.permutation(iterable)


def iterate_eternally(indices):
    def infinite_shuffles():
        while True:
            yield np.random.permutation(indices)

    return itertools.chain.from_iterable(infinite_shuffles())

def grouper(iterable, n):
    "Collect data into fixed-length chunks or blocks"
    # grouper('ABCDEFG', 3) --> ABC DEF"
    args = [iter(iterable)] * n
    return zip(*args)


class TwoStreamBatchSampler(Sampler):
    """Iterate two sets of indices

    An 'epoch' is one iteration through the primary indices.
    During the epoch, the secondary indices are iterated through
    as many times as needed.
    """

    def __init__(self, primary_indices, secondary_indices, batch_size, secondary_batch_size):
        self.primary_indices = primary_indices
        self.secondary_indices = secondary_indices
        self.secondary_batch_size = secondary_batch_size
        self.primary_batch_size = batch_size - secondary_batch_size

        assert len(self.primary_indices) >= self.primary_batch_size > 0
        assert len(self.secondary_indices) >= self.secondary_batch_size > 0

    def __iter__(self):
        primary_iter = iterate_once(self.primary_indices)
        secondary_iter = iterate_eternally(self.secondary_indices)
        return (
            primary_batch + secondary_batch
            for (primary_batch, secondary_batch) in zip(
                grouper(primary_iter, self.primary_batch_size),
                grouper(secondary_iter, self.secondary_batch_size),
            )
        )

    def __len__(self):
        return len(self.primary_indices) // self.primary_batch_size


def train():
    base_lr = 0.001
    D_lr = 0.001
    ema_decay = 0.99
    num_classes = 2
    batch_size = 2
    labeled_slice = 100
    labeled_bs = 1
    base_dir = './data/skin/'
    dataset = 'skin'
    image_size = (512,512)
    consistency = 0.1
    max_epoch = 301
    model_arch = 'resnet'


    # img_path =r"D:\2024\ssr\DATA\CHASE\train\image"
    # mask_path =r"D:\2024\ssr\DATA\CHASE\train\mask"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\train\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\train\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\train\image"
    # mask_path =r"D:\2024\ssr\DATA\CXR\train\mask"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\train\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\train\mask"


    weights_dict = {'resnet':torch.load('./resnet34.pth'),       'vgg16': torch.load('./vgg16_bn.pth'),
                    'mobilev2':torch.load('./mobilenet_v2.pth'),   'efficient': torch.load('./efficientnet_b0.pth')}
    
    def create_model(ema=False):
        models_dict = {'resnet':resnet34(num_classes),   'vgg16': VGG16(num_classes,True),
                   'mobilev2':MobileNetV2(num_classes = num_classes), 'efficient': EfficientNet.from_name('efficientnet-b0',num_classes = num_classes) }
        model = models_dict[model_arch]
        if ema:
            for param in model.parameters():
                param.detach_()
        return model

    model = create_model()
    pretrained_dict = weights_dict[model_arch]
    model_dict = model.state_dict()
    pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
    model_dict.update(pretrained_dict)
    model.load_state_dict(model_dict)
    model.cuda()
    ema_model = create_model(ema=False)
   
    summary(model, input_size=(3, 512,512), batch_size=1)
    ema_model.cuda()
    DAN = Discriminator(num_classes,1)
    DAN = DAN.cuda()
    
    # db_train = vessel_BaseDataSets(base_dir+'train/', 'train.txt',image_size,dataset,transform=transforms.Compose([RandomGenerator()]))
    # db_valid = vessel_BaseDataSets(base_dir+'test/', 'test.txt',image_size,dataset, transform=transforms.Compose([RandomGenerator()]))

    # total_slices = len(db_train)
    # print("Total images is: {}, labeled images is: {}".format(total_slices, labeled_slice))
    # labeled_idxs = list(range(0, labeled_slice))
    # unlabeled_idxs = list(range(labeled_slice, total_slices))
    # batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, batch_size, batch_size-labeled_bs)
    #batch_sampler = TwoStreamBatchSampler(unlabeled_idxs, labeled_idxs, batch_size, batch_size-labeled_bs)

    pixel_mean = [0.5] * 3
    pixel_std = [0.5] * 3
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]


        print("train with {} imgs".format(len(img_paths)))
        # mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.tif') for file in
        #       img_paths]
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + (
           '.png' if os.path.splitext(file)[1].lower() == '.png' else '.gif')) for file in img_paths]

    traindataset = SegDataset(img_paths, mask_paths=mask_paths, mask_divide=True,
                              divide_value=255,
                              pixel_mean=pixel_mean, pixel_std=pixel_std, img_size=1024)
    total_slices = len(traindataset)
    labeled_idxs = list(range(0, 7))
    unlabeled_idxs = list(range(7, total_slices))
    batch_sampler = TwoStreamBatchSampler(
        labeled_idxs, unlabeled_idxs, batch_size, batch_size - labeled_bs)
    trainloader = DataLoader(traindataset, batch_sampler=batch_sampler,
                             num_workers=1, pin_memory=False)



    # train_loader = DataLoader(db_train, batch_sampler=batch_sampler,num_workers=0, pin_memory=True)
    # valid_loader = DataLoader(db_valid, batch_size=batch_size, shuffle=False,num_workers=0)

    # print('train len:', len(train_loader))
    print('train len:', total_slices)
    #optimizer = optim.SGD(model.parameters(), lr=base_lr,momentum=0.9, weight_decay=0.0001)
    optimizer = optim.Adam(model.parameters(), betas=(0.9,0.99), lr=base_lr, weight_decay=0.0001)
    optimizer_T = optim.Adam(ema_model.parameters(), betas=(0.9,0.99), lr=0.0001, weight_decay=0.0001)
    DAN_optimizer = optim.Adam(DAN.parameters(), lr=D_lr, betas=(0.9, 0.99),weight_decay=0.0001)
    
    ce_loss = CrossEntropyLoss()

    iter_num = 0
    max_iterations =  max_epoch * len(trainloader)
    # max_epoch = 300
    iterator = tqdm(range(max_epoch), ncols=70)
    # max_iterations = max_epoch * len(traindataset)
    iter_num=0
    metric1 = Metric(num_classes=num_classes)
    metric2 = Metric(num_classes=num_classes)
    for epoch_num in iterator:
        train_acc = 0
        train_loss = 0
        test_acc =0

        # print('Epoch: {} / {} '.format(epoch_num, max_epoch))
        for num,sampled_batch in enumerate(trainloader):
            images, labels = sampled_batch['image'], sampled_batch['label']
            images, labels = images.cuda(), labels.cuda()
            unlabeled_images = images[labeled_bs:]
            
            '''
            print(sampled_batch['idx'] [0:labeled_bs])
            print('#########################')
            '''
            model.train()
            
            for param in model.parameters():
                param.requires_grad = True
            
            for param in ema_model.parameters():
                param.requires_grad = True
                
            for param in DAN.parameters():
                param.requires_grad = False
            
            noise = torch.clamp(torch.randn_like(unlabeled_images) * 0.1, -0.2, 0.2)
            ema_inputs = unlabeled_images

            outputs = model(images)
            outputs_soft = torch.softmax(outputs, dim=1)
            supervised_loss = ce_loss(outputs[:labeled_bs],labels[:labeled_bs].long())
            '''
            with torch.no_grad():
                ema_output = ema_model(ema_inputs)
                ema_output_soft = torch.softmax(ema_output, dim=1)
                ema_output_label = torch.max(ema_output_soft,1)[1]
            '''
            ema_output = ema_model(ema_inputs)
            ema_output_soft = torch.softmax(ema_output, dim=1)
            ema_output_label = torch.max(ema_output_soft,1)[1]
            
            DAN_outputs = DAN(outputs_soft[labeled_bs:,1:2,:,:], ema_inputs)
            DAN_outputs2 = DAN(ema_output_soft[:,1:2,:,:], ema_inputs)
            
            
            DAN_target = torch.tensor([0] * batch_size).cuda()
            DAN_target[:labeled_bs] = 1
            gan_loss = F.cross_entropy(DAN_outputs, DAN_target[:labeled_bs].long())+ F.cross_entropy(DAN_outputs2, DAN_target[:labeled_bs].long())
            

            if iter_num < 200:
                consistency_loss = 0.0
                unsupervised_loss = 0.0
                
            else:
                consistency_loss = torch.mean((outputs_soft[labeled_bs:]-ema_output_soft)**2)
                unsupervised_loss = ce_loss(outputs[labeled_bs:],ema_output_label.long())
                
            
            consistency_weight = get_current_consistency_weight(consistency,epoch_num,max_epoch)
            loss = supervised_loss + consistency_weight* (consistency_loss + unsupervised_loss + gan_loss) 
            
            prediction = torch.max(outputs[:labeled_bs],1)[1]
            train_correct = (prediction == labels[:labeled_bs]).float().mean().cpu().numpy()
            train_acc = train_acc + train_correct
            train_loss = train_loss + loss.detach().cpu().numpy()
            
            
            optimizer.zero_grad()
            optimizer_T.zero_grad()
            loss.backward()
            optimizer.step()
            optimizer_T.step()
            update_ema_variables(model, ema_model, ema_decay, iter_num)
            
            #model.eval()
            for param in model.parameters():
                param.requires_grad = False
            for param in ema_model.parameters():
                param.requires_grad = False
            for param in DAN.parameters():
                param.requires_grad = True
            
            
            with torch.no_grad():
                outputs = model(images)
                outputs_soft = torch.softmax(outputs, dim=1)
                output_label = torch.max(outputs_soft,1)[1]
                outputs2 = ema_model(images)
                outputs_soft2 = torch.softmax(outputs2, dim=1)
            
                
            DAN_outputs1 = DAN(outputs_soft[:,1:2,:,:], images)
            DAN_outputs2 = DAN(outputs_soft2[:,1:2,:,:], images)
            DAN_target1 = torch.tensor([0] * batch_size).cuda()
            DAN_target1[0:labeled_bs] = 1
            D_loss = F.cross_entropy(DAN_outputs1, DAN_target1.long()) + F.cross_entropy(DAN_outputs2, DAN_target1.long())
            
            DAN_optimizer.zero_grad()
            D_loss.backward()
            DAN_optimizer.step()
            
            lr = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr
            D_lr = D_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in DAN_optimizer.param_groups:
                param_group['lr'] = D_lr
            
            for param in ema_model.parameters():
                param.requires_grad = True
                
            ema_output = ema_model(images)
            teacher_sup_loss = ce_loss(ema_output[:labeled_bs],labels[:labeled_bs].long())
            if iter_num < 300:
                teacher_unsup_loss = 0.0
            else:
                teacher_unsup_loss = ce_loss(ema_output[labeled_bs:],output_label[labeled_bs:].long())
            teacher_loss =  teacher_sup_loss + teacher_unsup_loss
            optimizer_T.zero_grad()
            teacher_loss.backward()
            optimizer_T.step()
            
            update_ema_variables(ema_model, model, ema_decay, iter_num)
            
            lr_T = 0.0001 * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr_T

            metric1.update(outputs_soft, labels)
            # metric2.update(ema_output_soft, ema_output_la)
            iter_num = iter_num + 1
        iou1 = np.nanmean(metric1.evaluate()["iou"][1:].numpy())
        print("epoch_num-{}: iou1:{}".format(epoch_num + 1, iou1.item()))

        dice1 = np.nanmean(metric1.evaluate()["dice"][1:].numpy())
        print("epoch_num-{}: dice1:{}".format(epoch_num + 1, dice1.item()))

        acc1 = np.nanmean(metric1.evaluate()["acc"][1:].numpy())

        print("epoch_num-{}: acc1:{}".format(epoch_num + 1, acc1.item()))
        # iou2 = np.nanmean(metric2.evaluate()["iou"][1:].numpy())
        # print("epoch_num-{}: iou2:{}".format(epoch_num + 1, iou2.item()))
        #
        # dice2 = np.nanmean(metric2.evaluate()["dice"][1:].numpy())
        # print("epoch_num-{}: dice2:{}".format(epoch_num + 1, dice2.item()))
        #
        # acc2 = np.nanmean(metric2.evaluate()["acc"][1:].numpy())
        #
        # print("epoch_num-{}: acc2:{}".format(epoch_num + 1, acc2.item()))
        ##  test
        # model.eval()
        # for i_batch, sampled_batch in enumerate(valid_loader):
        #     images, labels = sampled_batch['image'], sampled_batch['label']
        #     images, labels = images.cuda(), labels.cuda()
        #     with torch.no_grad():
        #         outputs = model(images)
        #         outputs_soft = torch.softmax(outputs, dim=1)
        #         prediction = torch.max(outputs,1)[1]
        #         test_correct = (prediction == labels).float().mean().cpu().numpy()
        #         test_acc = test_acc + test_correct
        # print('train_loss: ',train_loss/(labeled_slice/labeled_bs),' train_acc: ',train_acc/(labeled_slice/labeled_bs),'test_acc: ',test_acc/len(valid_loader))
        model.train()
        save_path = "./code/new/Kavsir-SEG"
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        if epoch_num%100 == 0:
            os.path.join(save_path, "{}epoch_model2.pth".format(epoch_num))


            torch.save(model.state_dict(), os.path.join(save_path, "student_{}epoch.pth".format(epoch_num)))
            torch.save(ema_model.state_dict(), os.path.join(save_path, "teacher_{}epoch.pth".format(epoch_num)))

if __name__ == '__main__':
    train()
