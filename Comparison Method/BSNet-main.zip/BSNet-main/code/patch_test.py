import glob
import shutil

from matplotlib import pyplot as plt
from thop import profile

from metrics.metric import Metric
from models import *
from dataset import *
from utils import *
from efficientNet import *
from torchvision import transforms
import copy
import torch
from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip

class testDataset:
    def __init__(self, img_paths, mask_paths,
                 mask_divide=True, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=1024) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size


    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        # img = tf.imread(img_path)
        img = Image.open(img_path).convert("RGB")
        img = np.asarray(img)
        mask = Image.open(mask_path).convert("L")
        mask = np.asarray(mask)


        if self.mask_divide:
            mask = mask // self.divide_value
        transform = Compose(
            [
                # ColorJitter(),
                # VerticalFlip(),
                # HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )
        aug_data = transform(image=img, mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        return torch.from_numpy(x), torch.from_numpy(target).float()
def extract_ordered_overlap(image,patch_size,s):
    
    image_h = image.shape[2]  
    image_w = image.shape[3] 
    N_patches_img = ((image_h-patch_size)//s+1)*((image_w-patch_size)//s+1) 
    
    patches = torch.empty((N_patches_img,3,patch_size,patch_size))
    #print(patches.shape)
    iter_tot = 0   
    for h in range((image_h-patch_size)//s+1):
        for w in range((image_w-patch_size)//s+1):
            patch = image[0,:,h*s:(h*s)+patch_size,w*s:(w*s)+patch_size]
            patches[iter_tot]=patch
            iter_tot =iter_tot+1      
    return patches

def recompone_overlap(preds, img_h, img_w, s):
    #print(preds.shape)
    patch_h = preds.shape[2]
    patch_w = preds.shape[3]
    N_patches_h = (img_h-patch_h)//s+1
    N_patches_w = (img_w-patch_w)//s+1
    N_patches_img = N_patches_h * N_patches_w
    
    full_prob = torch.zeros((1,preds.shape[1],img_h,img_w)).cuda()
    full_sum =  torch.zeros((1,preds.shape[1],img_h,img_w)).cuda()
    k = 0
   
    for h in range((img_h-patch_h)//s+1):
        for w in range((img_w-patch_w)//s+1):
            
            full_prob[:,:,h*s:(h*s)+patch_h,w*s:(w*s)+patch_w]+=preds[k]
            full_sum [:,:,h*s:(h*s)+patch_h,w*s:(w*s)+patch_w]+=1
            k+=1
    
    final_avg = full_prob/full_sum
    
    return final_avg

def main():
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    num_classes = 2
    batch_size = 1
    image_size = (1024, 1024)
    save_dir = './result/'
    patch_size = 1024
    stride = 256
    MT = 1
    base_dir = './data/drive/test/'
    dataset = 'polyp'

    # img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\images"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # img_path = r"D:\2024\ssr\DATA\FIVES\test\Original"
    # mask_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # prompt_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # img_path = r"D:\2024\ssr\DATA\STARE\Images"
    # mask_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # prompt_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image\CXR_4"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # prompt_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\test\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path =r"D:\2024\ssr\DATA\CXR\test\mask"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\image"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # db_val = testBaseDataSets(base_dir, 'test.txt',image_size,dataset,transform=transforms.Compose([RandomGenerator()]))
    # valloader = DataLoader(db_val, batch_size=batch_size, shuffle=False,num_workers=0)
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))

        # mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file in
        #               img_paths]
        # mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '_1stHO' + '.png') for file
        #               in
        #               img_paths]

        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file in
                      img_paths]

        # mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.tif') for file in
        #               img_paths]

    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)
    metric1 = Metric(num_classes=2)
    metric2 = Metric(num_classes=2)
    if MT:

        # T_model_name = 'UAMT_teacher_drive_'  # our_resnet_teacher_skin_
        # S_model_name = 'UAMT_student_drive_'  # our_resnet_student_skin_
        T_model_name = 'teacher_'
        S_model_name = 'student_'

        T_model = resnet34(num_classes)
        S_model = copy.deepcopy(T_model)
        print(id(T_model), id(S_model))


        T_model.load_state_dict(torch.load('./code/new/Kavsir-SEG/' + T_model_name +'200epoch' + '.pth'))
        T_model.cuda()
        T_model.eval()
        S_model.load_state_dict(torch.load('./code/new/Kavsir-SEG/' + S_model_name+ '200epoch'+ '.pth'))
        S_model.cuda()
        S_model.eval()
        j = 0
        evaluator_T = Evaluator()
        evaluator_S = Evaluator()
        test_save_path = r"D:\2024\ssr\BSNet-main\Kavsir-SEG\BSNet"
        if os.path.exists(test_save_path):
            shutil.rmtree(test_save_path)
        os.makedirs(test_save_path)

        dummy_input = torch.randn(1, 3, 1024, 1024).cuda()
        macs, params = profile(T_model, inputs=(dummy_input,), verbose=False)
        print(f"FLOPs: {macs / 1e9:.2f} GFLOPs")
        print(f"Params: {params / 1e6:.2f} M")

        # === 计算 FPS ===
        with torch.no_grad():
            for _ in range(10):  # 预热
                _ = T_model(dummy_input)
            start_time = time.time()
            for _ in range(100):
                _ = T_model(dummy_input)
            end_time = time.time()
            fps = 100 / (end_time - start_time)
            print(f"FPS: {fps:.2f} frames/sec")


        with torch.no_grad():
            for i,(x, target) in enumerate(dataloader):
                images, labels = x, target
                images, labels = images.cuda(), labels.cuda()
                ####add######
                patches = extract_ordered_overlap(images, patch_size, stride)
                print(patches.shape)
                predictions_T = T_model(images.cuda())
                pred_T = predictions_T[:, :, :, :]
                pred_T = recompone_overlap(pred_T, 1024, 1024, stride)
                print(pred_T.shape)
                metric1.update(predictions_T, labels)
                # evaluator_T.update(pred_T, labels[0, :, :].float())
                predictions_S = S_model(images.cuda())
                pred_S = predictions_S[:, :, :, :]
                pred_S = recompone_overlap(pred_S, 1024, 1024, stride)
                evaluator_S.update(pred_S, labels[0, :, :].float())
                metric2.update(predictions_S, labels)
                pred = torch.max(predictions_T, dim=1)[1]


                predname = f"./pred{i + 1}.png"
                pred_path = os.path.join(test_save_path, predname)
                pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
                plt.figure(figsize=(10, 10))
                plt.imshow(pred_image, cmap='gray', interpolation='none')
                plt.axis('off')
                plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
                plt.close('all')

        #
        # evaluator_T.show()
        # evaluator_S.show()


    else:

        model_name = 'URPC_drive_'  # URPC_drive_
        model = resnet34(num_classes)

        for k in range(300, 303, 3):
            print('./new/' + model_name + str(k) + '.pth')
            model.load_state_dict(torch.load('./new/' + model_name + str(k) + '.pth'))
            model.cuda()
            model.eval()
            j = 0
            evaluator = Evaluator()
            with torch.no_grad():
                for sampled_batch in dataloader:
                    images, labels = sampled_batch['image'], sampled_batch['label']
                    images, labels = images.cuda(), labels.cuda()
                    patches = extract_ordered_overlap(images, patch_size, stride)
                    # print(patches.shape)
                    # outputs_tanh, predictions = model(patches.cuda())
                    predictions, _, _, _ = model(patches.cuda())
                    # predictions = model(patches.cuda())
                    # print(predictions.shape)
                    pred = predictions[:, 1, :, :]
                    pred = recompone_overlap(pred, 512, 512, stride)

                    # print(pred.shape)
                    evaluator.update(pred, labels[0, :, :].float())

                    for i in range(batch_size):
                        labels = labels.cpu().numpy()
                        label = (labels[i] * 255)
                        pred = pred.cpu().numpy()
                        # total_img = np.concatenate((label,pred[:,:]*255),axis=1)
                        cv2.imwrite(save_dir + 'GT_Pre' + str(j) + '.jpg', pred[:, :] * 255)
                        j = j + 1
            evaluator.show()
    iou = np.nanmean(metric1.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric1.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric1.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric1.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric1.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))


if __name__ == '__main__':
    main()