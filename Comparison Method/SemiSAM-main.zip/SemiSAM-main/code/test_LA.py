import os
import argparse
import shutil

import numpy as np
import torch
from tqdm import tqdm

from networks.vnet import VNet
from test_util import test_single_volume, test_all_case

# from test_util import test_all_case

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default=r"D:\2024\ssr\DATA\ACDC", help='Name of Experiment')
parser.add_argument('--model', type=str,  default='SemiSAM-MT-2', help='model_name')
parser.add_argument('--gpu', type=str,  default='0', help='GPU to use')
FLAGS = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = FLAGS.gpu
snapshot_path = "../model/"+FLAGS.model+"/"
test_save_path = r"D:\2024\ssr\SemiSAM-main\ACDC\SmeiSAM"
if os.path.exists(test_save_path):
    shutil.rmtree(test_save_path)
os.makedirs(test_save_path)
num_classes = 4

with open(FLAGS.root_path + '/test.list', 'r') as f:
    image_list = f.readlines()
image_list = sorted([item.replace('\n', '').split(".")[0]
                     for item in image_list])

def test_calculate_metric(epoch_num):
    net = VNet(n_channels=1, n_classes=num_classes, normalization='batchnorm', has_dropout=False).cuda()
    save_mode_path =r"D:\2024\ssr\SemiSAM-main\model\ACDC\iter_16000.pth"
    net.load_state_dict(torch.load(save_mode_path))
    print("init weight from {}".format(save_mode_path))
    net.eval()

    # avg_metric = test_all_case(net, image_list, num_classes=num_classes,
    #                            patch_size=(128, 128, 128), stride_xy=18, stride_z=4,
    #                            save_result=True, test_save_path=test_save_path)

    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    first_list = np.zeros([len(image_list), 4])
    second_list = np.zeros([len(image_list), 4])
    third_list = np.zeros([len(image_list), 4])
    count = 0
    for case in tqdm(image_list):
        first_metric, second_metric, third_metric = test_single_volume(
            case, net, test_save_path, FLAGS)
        first_total += np.asarray(first_metric)
        second_total += np.asarray(second_metric)
        third_total += np.asarray(third_metric)

        first_total += np.asarray(first_metric)
        second_total += np.asarray(second_metric)
        third_total += np.asarray(third_metric)

        # save
        first_list[count, 0] = first_metric[0]
        first_list[count, 1] = first_metric[1]
        first_list[count, 2] = first_metric[2]
        first_list[count, 3] = first_metric[3]

        second_list[count, 0] = second_metric[0]
        second_list[count, 1] = second_metric[1]
        second_list[count, 2] = second_metric[2]
        second_list[count, 3] = second_metric[3]

        third_list[count, 0] = third_metric[0]
        third_list[count, 1] = third_metric[1]
        third_list[count, 2] = third_metric[2]
        third_list[count, 3] = third_metric[3]

        count += 1


    avg_metric1 = np.nanmean(first_list, axis=0)
    avg_metric2 = np.nanmean(second_list, axis=0)
    avg_metric3 = np.nanmean(third_list, axis=0)
    print(avg_metric1, avg_metric2, avg_metric3)
    print((avg_metric1 + avg_metric2 + avg_metric3) / 3)


if __name__ == '__main__':
   test_calculate_metric(6000)
