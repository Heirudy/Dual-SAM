import glob
import os
import argparse
import re
import shutil
import time

import torch
from torch.utils.data import DataLoader

from dataset import testDataset
from metrics.metric import Metric
from networks.vnet import VNet
from test2D_util import test_all_case

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default='../data/2018LA_Seg_Training Set/', help='Name of Experiment')
parser.add_argument('--model', type=str,  default='SemiSAM-MT-2', help='model_name')
parser.add_argument('--gpu', type=str,  default='0', help='GPU to use')
FLAGS = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = FLAGS.gpu
snapshot_path = r"D:\2024\ssr\SemiSAM-main\model\CXR\iter_600.pth"
test_save_path = "../model/prediction/"+FLAGS.model+"_post/"
if not os.path.exists(test_save_path):
    os.makedirs(test_save_path)

num_classes = 2



with open(FLAGS.root_path + '/../test.list', 'r') as f:
    image_list = f.readlines()
image_list = [FLAGS.root_path +item.replace('\n', '')+"/mri_norm2.h5" for item in image_list]


def test_calculate_metric(epoch_num):
    net = VNet(n_channels=1, n_classes=num_classes, normalization='batchnorm', has_dropout=False).cuda()
    save_mode_path = r"D:\2024\ssr\SemiSAM-main\model\CHASE\iter_1000.pth"
    net.load_state_dict(torch.load(save_mode_path))
    print("init weight from {}".format(save_mode_path))
    net.eval()
    img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=128)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)
    metric = Metric(num_classes=2)

    from thop import profile, clever_format
    import time
    dummy_input = torch.randn(1,1, 128, 128, 128).cuda()
    flops, params = profile(net, inputs=(dummy_input,), verbose=False)
    flops, params = clever_format([flops, params], "%.3f")
    print(f"FLOPs: {flops}, Params: {params}")
    start_time = time.time()
    for _ in range(100):
        with torch.no_grad():
            _ = net(dummy_input)
    end_time = time.time()
    fps = 100 / (end_time - start_time)
    print(f"FPS: {fps:.2f}")


    test_save_path=r"D:\2024\ssr\SemiSAM-main\CHASE\SemiSAM"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    test_all_case(net, dataloader,metric, num_classes=num_classes,
                               patch_size=(128, 128, 128), stride_xy=18, stride_z=4,
                               save_result=True, test_save_path=test_save_path)




if __name__ == '__main__':
   test_calculate_metric(6000)
