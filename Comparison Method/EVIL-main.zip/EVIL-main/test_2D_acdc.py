import argparse
import glob
import os
import re
import shutil
# import h5py
import nibabel as nib
import numpy as np
import SimpleITK as sitk
import torch
from PIL import Image
from medpy import metric
# from scipy.ndimage import zoom
from scipy.ndimage.interpolation import zoom
from torch.utils.data import DataLoader
from tqdm import tqdm

from metrics.metric import Metric
from networks.unet import UNet
import matplotlib.pyplot as plt
from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip



parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default='./data/ACDC', help='Name of Experiment')
parser.add_argument('--dataset', type=str,
                    default='ACDC', help='Dataset')
parser.add_argument('--exp', type=str,
                    default='EVIL', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='unet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=2,
                    help='output channel of network')
parser.add_argument('--seed', type=int,  default=1337,
                    help='random seed')
parser.add_argument('--labeled_num', type=int, default=7,
                    help='labeled data')
parser.add_argument('--patch_size', type=int, default=[1024, 1024],
                    help='labeled data')
class testDataset:
    def __init__(self, img_paths, mask_paths,


                 mask_divide=False, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=1024) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size

        # self.bbox_shift = bbox_shift

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        img = Image.open(img_path).convert("RGB")
        # img = tf.imread(img_path)
        mask = Image.open(mask_path).convert("L")

        img = np.asarray(img)
        mask = np.asarray(mask)
        if self.mask_divide:
            mask = mask // self.divide_value
        # sample = {"image": img, "label": mask}
        # if None not in (self.ops_weak, self.ops_strong):
        #         sample = self.transform(sample, self.ops_weak, self.ops_strong)
        # else:
        #         sample = self.transform(sample)
        transform = Compose(
            [
                # ColorJitter(),
                # VerticalFlip(),
                # HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )

        aug_data = transform(image=img,mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        sample = {"image": torch.from_numpy(x), "label": torch.from_numpy(target)}
        # sample = {"image": x, "label": target}
        return sample

def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    pred = pred.astype(np.uint8)
    gt = gt.astype(np.uint8)
    dice = metric.binary.dc(pred, gt) * 100.0
    asd = metric.binary.asd(pred, gt) if np.sum(pred) != 0 else 100
    hd95 = metric.binary.hd95(pred, gt)
    return dice, hd95, asd


def test_single_volume3d(sampled_batch, net, test_save_path, FLAGS,metric,i):
    # h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    # image = h5f['image'][:]
    # label = h5f['label'][:]
    # prediction = np.zeros_like(label)
    # input = np.zeros((image.shape[0], FLAGS.patch_size[0], FLAGS.patch_size[1]))
    image, target = sampled_batch['image'], sampled_batch['label']
    # x, y = image.shape[1], image.shape[2]
    # for ind in range(image.shape[0]):
    #     slice = image[ind, :, :]
    #     slice = zoom(slice, (FLAGS.patch_size[0] / x, FLAGS.patch_size[1] / y), order=0)
    #     input[ind,:] = slice

    # input_tensor = torch.from_numpy(input).unsqueeze(1).float().cuda()
    input_tensor=image.float().cuda()

    with torch.no_grad():
        if FLAGS.model == "unet_urpc" or FLAGS.model == "unet_cct":
            out_main, _, _, _ = net(input_tensor)
        else:
            out_main = net(input_tensor)
        out = torch.softmax(out_main, dim=1)
        metric.update(out, target)
        pred = torch.max(out, dim=1)[1]
        predname = f"./pred{i + 1}.png"
        pred_path = os.path.join(test_save_path, predname)
        pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
        plt.figure(figsize=(10, 10))
        plt.imshow(pred_image, cmap='gray', interpolation='none')
        plt.axis('off')
        plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        plt.close('all')


        # out = torch.argmax(torch.softmax(
        #     out_main, dim=1), dim=1).squeeze(1)
    #     out = out.cpu().detach().numpy()
    #     for ind in range(out.shape[0]):
    #         slice = out[ind, :, :]
    #         pred = zoom(slice, (x / FLAGS.patch_size[0], y / FLAGS.patch_size[1]), order=0)
    #         prediction[ind] = pred
    #
    # RV_metric = calculate_metric_percase(prediction == 1, label == 1)
    # LV_metric = calculate_metric_percase(prediction == 2, label == 2)
    # Myo_metric = calculate_metric_percase(prediction == 3, label == 3)
    #
    # img_itk = sitk.GetImageFromArray(image.astype(np.float32))
    # img_itk.SetSpacing((1, 1, 10))
    # prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
    # prd_itk.SetSpacing((1, 1, 10))
    # lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
    # lab_itk.SetSpacing((1, 1, 10))
    # sitk.WriteImage(prd_itk, test_save_path + case + "_pred.nii")
    # sitk.WriteImage(img_itk, test_save_path + case + "_img.nii")
    # sitk.WriteImage(lab_itk, test_save_path + case + "_gt.nii")
    # return RV_metric, LV_metric, Myo_metric


def Inference(FLAGS):
    # with open(FLAGS.root_path + '/test.list', 'r') as f:
    #     image_list = f.readlines()
    # image_list = sorted([item.replace('\n', '').split(".")[0]
    #                      for item in image_list])

    # snapshot_path = "./model/{}/{}_{}_{}/{}".format(FLAGS.dataset,
    #     FLAGS.exp, FLAGS.labeled_num, FLAGS.seed, FLAGS.model)
    # test_save_path = "./model/{}/{}_{}_{}/{}_predictions/".format(FLAGS.dataset,
    #     FLAGS.exp, FLAGS.labeled_num,  FLAGS.seed, FLAGS.model)
    # if os.path.exists(test_save_path):
    #     shutil.rmtree(test_save_path)
    # os.makedirs(test_save_path)

    # img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\FIVES\test\Original"
    # mask_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # prompt_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # img_path = r"D:\2024\ssr\DATA\STARE\Images"
    # mask_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # prompt_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image\CXR_4"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # prompt_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"

    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\image"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\images"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\test\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path =r"D:\2024\ssr\DATA\CXR\test\mask"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    # image = h5f['image'][:]
    # label = h5f['label'][:]
    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)


    net = UNet(in_chns=3, class_num=FLAGS.num_classes).cuda()
    save_mode_path = r"D:\2024\ssr\EVidential-Inference-Learning-main\model\Kavsir-SEG\EVIL_70_887\unet\model1_epoch_300.pth"
    net.load_state_dict(torch.load(save_mode_path))
    print("init weight from {}".format(save_mode_path))
    net.eval()

    from thop import profile, clever_format
    import time
    dummy_input = torch.randn(1, 3, 1024, 1024).cuda()
    flops, params = profile(net, inputs=(dummy_input,), verbose=False)
    flops, params = clever_format([flops, params], "%.3f")
    print(f"FLOPs: {flops}, Params: {params}")

    # 计算 FPS 的代码
    start_time = time.time()
    for _ in range(100):
        with torch.no_grad():
            _ = net(dummy_input)
    end_time = time.time()
    fps = 100 / (end_time - start_time)
    print(f"FPS: {fps:.2f}")

    # LV_total = 0.0
    # RV_total = 0.0
    # Myo_total = 0.0
    metric = Metric(num_classes=2)
    test_save_path=r"D:\2024\ssr\EVidential-Inference-Learning-main\Kavsir-SEG\EVIL"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    for i, sample in enumerate(dataloader):
        test_single_volume3d(sample, net, test_save_path, FLAGS, metric, i)
    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))
    # for case in tqdm(image_list):
    #     RV_metric, LV_metric, Myo_metric = test_single_volume3d(
    #         case, net, test_save_path, FLAGS)
    #     LV_total += np.asarray(LV_metric)
    #     RV_total += np.asarray(RV_metric)
    #     Myo_total += np.asarray(Myo_metric)
    #
    # avg_metric = [RV_total / len(image_list), LV_total / len(image_list),
    #               Myo_total / len(image_list)]
    # return avg_metric


if __name__ == '__main__':
    FLAGS = parser.parse_args()
    Inference(FLAGS)
    # print('RV: ', metrics[0])
    # print('LV: ', metrics[1])
    # print('Myo: ', metrics[2])
    # # print(metric)
    # print('Mean: ', (metrics[0]+metrics[1]+metrics[2])/3)
