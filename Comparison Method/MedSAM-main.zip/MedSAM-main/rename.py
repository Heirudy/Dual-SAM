import os
import shutil


def rename_images_to_png(folder_path):
    """
    将指定文件夹内所有图片的后缀改为 .png
    :param folder_path: 文件夹路径
    """
    # 检查文件夹是否存在
    if not os.path.exists(folder_path):
        print(f"文件夹 {folder_path} 不存在！")
        return

    # 遍历文件夹内的所有文件
    for filename in os.listdir(folder_path):
        # 获取文件的完整路径
        file_path = os.path.join(folder_path, filename)

        # 检查是否为文件
        if os.path.isfile(file_path):
            # 分离文件名和后缀
            name, ext = os.path.splitext(filename)

            # 检查是否为图片文件（这里假设图片文件后缀为常见的几种）
            if ext.lower() in ['.jpg', '.jpeg', '.bmp', '.gif', '.tiff', '.png']:
                # 构造新的文件名
                new_file_path = os.path.join(folder_path, f"{name}.png")

                # 如果文件已经是 .png 后缀，则跳过
                if ext.lower() == '.png':
                    print(f"文件 {filename} 已经是 .png 格式，跳过。")
                else:
                    # 重命名文件
                    shutil.move(file_path, new_file_path)
                    print(f"文件 {filename} 已重命名为 {os.path.basename(new_file_path)}")

    print("处理完成！")


# 示例用法
folder_path = r"D:\2024\ssr\DATA\fewdata\CHASE\image"
rename_images_to_png(folder_path)