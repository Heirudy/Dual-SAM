# -*- coding: utf-8 -*-
# %% load environment
import random
import time

import cv2
import h5py
import numpy as np
import matplotlib.pyplot as plt
import os

from medpy import metric
from scipy.ndimage import zoom
from tqdm import tqdm

from metrics.metric import Metric

join = os.path.join
import torch
from segment_anything import sam_model_registry
from skimage import io, transform
import torch.nn.functional as F
import argparse
import SimpleITK as sitk

# visualization functions
# source: https://github.com/facebookresearch/segment-anything/blob/main/notebooks/predictor_example.ipynb
# change color to avoid red and green
def show_mask(mask, ax, random_color=False):
    if random_color:
        color = np.concatenate([np.random.random(3), np.array([0.6])], axis=0)
    else:
        color = np.array([251 / 255, 252 / 255, 30 / 255, 0.6])
    h, w = mask.shape[-2:]
    mask_image = mask.reshape(h, w, 1) * color.reshape(1, 1, -1)
    ax.imshow(mask_image)


def show_box(box, ax):
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(
        plt.Rectangle((x0, y0), w, h, edgecolor="blue", facecolor=(0, 0, 0, 0), lw=2)
    )


@torch.no_grad()
def medsam_inference(medsam_model, img_embed, box_1024, H, W):
    # box_torch = torch.as_tensor(box_1024, dtype=torch.float, device=img_embed.device)
    box_torch =box_1024
    # if len(box_torch.shape) == 0:
    #     box_torch = box_torch.unsqueeze(1)  # (B, 1, 4)
    # if (box_torch == 0).all():
    #     box_torch=None
    sparse_embeddings, dense_embeddings = medsam_model.prompt_encoder(
        points=None,
        boxes=None,
        masks=None,
    )
    low_res_logits, _ = medsam_model.mask_decoder(
        image_embeddings=img_embed,  # (B, 256, 64, 64)
        image_pe=medsam_model.prompt_encoder.get_dense_pe(),  # (1, 256, 64, 64)
        sparse_prompt_embeddings=sparse_embeddings,  # (B, 2, 256)
        dense_prompt_embeddings=dense_embeddings,  # (B, 256, 64, 64)
        multimask_output=False,
    )

    low_res_pred = torch.sigmoid(low_res_logits)  # (1, 1, 256, 256)

    low_res_pred = F.interpolate(
        low_res_pred,
        size=(H, W),
        mode="bilinear",
        align_corners=False,
    )  # (1, 1, gt.shape)
    low_res_pred = low_res_pred.squeeze().cpu().numpy()  # (256, 256)
    medsam_seg = (low_res_pred > 0.5).astype(np.uint8) * 255  # Convert to 8-bit format
    return medsam_seg

# %% load model and image
parser = argparse.ArgumentParser(
    description="run inference on testing set based on MedSAM"
)
parser.add_argument(
    "-i",
    "--data_path",
    type=str,
    default=r"D:\2024\ssr\DATA\CHASE\test\image",
    help="path to the data folder",
)
parser.add_argument(
    "-o",
    "--seg_path",
    type=str,
    default=r"E:\2023\ssr\MedSAM-main\ACDC\patient",
    help="path to the segmentation folder",
)
parser.add_argument(
    "--box",
    type=list,
    default=[250, 250, 2350, 2350],
    help="bounding box of the segmentation target",
)
parser.add_argument("--device", type=str, default="cuda:2", help="device")
parser.add_argument(
    "-chk",
    "--checkpoint",
    type=str,
    default=r"E:\2023\ssr\MedSAM-main\work_dir\MedSAM\sam_vit_b_01ec64.pth",
    help="path to the trained model",
)
parser.add_argument('--root_path', type=str,
                    default=r"E:\2023\ssr\ACDC", help='root dir for data')


def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    if pred.sum() != 0:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        print('bad')
        asd = -1
        hd95 = -1
    jc = metric.binary.jc(pred, gt)
    return dice, hd95, asd, jc

def test_single_volume(case, medsam_model, test_save_path, args):
    h5f = h5py.File(args.root_path + "/data/{}.h5".format(case), 'r')
    image = h5f['image'][:]
    label = h5f['label'][:]
    prediction = np.zeros_like(label)
    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        gt =label[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (1024 / x, 1024 / y), order=0)
        gt=zoom(gt, (1024 / x, 1024 / y), order=0)
        # label_np = gt
        # label_ids = np.unique(label_np)[1:]  # 忽略背景
        # gt2D = np.zeros((3, label_np.shape[0], label_np.shape[1]), dtype=np.uint8)  # 创建一个 4 通道的 one-hot 编码
        # for i, label_id in enumerate(label_ids):
        #     if i >= 3:
        #         break  # 只处理前 4 个类别
        #     gt2D[i] = label_np == label_id  # 每个通道对应一个类别
        # y_indices, x_indices = np.where(label_np > 0)
        # if (x_indices == 0).all():
        #     x_min = 0
        #     x_max = 0
        #
        # if (y_indices == 0).all():
        #     y_min = 0
        #     y_max = 0
        # else:
        #
        #     x_min, x_max = np.min(x_indices), np.max(x_indices)
        #     y_min, y_max = np.min(y_indices), np.max(y_indices)
        #
        #     # # 添加随机扰动
        #     H, W = 1024,1024
        #     bbox_shift = 20
        #     x_min = max(0, x_min - random.randint(0, bbox_shift))
        #     x_max = min(W, x_max + random.randint(0, bbox_shift))
        #     y_min = max(0, y_min - random.randint(0, bbox_shift))
        #     y_max = min(H, y_max + random.randint(0, bbox_shift))
        # box_1024= np.array([x_min, y_min, x_max, y_max])

        H=W=1024
        B=1
        device = 'cuda:2'
        img_1024_tensor = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().to(device)
        boxes = torch.from_numpy(np.array([[0, 0, W, H]] * B)).float().to(device)
        img_1024_tensor = img_1024_tensor.repeat(1, 3, 1, 1)
        with torch.no_grad():

            image_embedding = medsam_model.image_encoder(img_1024_tensor)

            sparse_embeddings, dense_embeddings = sam_model.prompt_encoder(
                points=None,
                boxes=boxes[:, None, :],
                masks=None,
            )
            # predicted masks
        mask_predictions, _ = sam_model.mask_decoder(
            image_embeddings=image_embedding.to(device),  # (B, 256, 64, 64)
            image_pe=sam_model.prompt_encoder.get_dense_pe(),  # (1, 256, 64, 64)
            sparse_prompt_embeddings=sparse_embeddings,  # (B, 2, 256)
            dense_prompt_embeddings=dense_embeddings,  # (B, 256, 64, 64)
            multimask_output=True,
        )
        out = torch.argmax(torch.softmax(
            mask_predictions, dim=1), dim=1).squeeze(0)
        # out = torch.from_numpy(out)
        # out = torch.argmax(out, dim=0)
        out = out.cpu().detach().numpy()
        pred = zoom(out, (x / 256, y / 256), order=0)
        prediction[ind] = pred
        # 从 case 中提取患者编号和帧编号
        patient_id, frame_id = case.split("_")  # 假设 case 格式为 "patient003_frame01"
        # 构造预测结果的文件名
        # pred_name = f"{patient_id}_{frame_id}_pred_{ind + 1}.png"
        # pred_path = os.path.join(test_save_path, pred_name)
        # # 保存预测结果
        # plt.figure(figsize=(10, 10))
        # plt.imshow(pred, cmap='gray', interpolation='none')
        # plt.axis('off')
        # plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        # plt.close('all')
        z_spacing = 1
        img_itk = sitk.GetImageFromArray(image.astype(np.float32))
        prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
        lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
        img_itk.SetSpacing((1, 1, z_spacing))
        prd_itk.SetSpacing((1, 1, z_spacing))
        lab_itk.SetSpacing((1, 1, z_spacing))
        sitk.WriteImage(prd_itk, test_save_path + '/' + case + "_pred.nii.gz")
        # sitk.WriteImage(img_itk, test_save_path + '/' + case + "_img.nii.gz")
        sitk.WriteImage(lab_itk, test_save_path + '/' + case + "_gt.nii.gz")
        print('saved successfully!')
    first_metric = calculate_metric_percase(prediction == 1, label == 1)
    second_metric = calculate_metric_percase(prediction == 2, label == 2)
    third_metric = calculate_metric_percase(prediction == 3, label == 3)
    # img_itk = sitk.GetImageFromArray(image.astype(np.float32))
    # img_itk.SetSpacing((1, 1, 10))
    # prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
    # prd_itk.SetSpacing((1, 1, 10))
    # lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
    # lab_itk.SetSpacing((1, 1, 10))
    # sitk.WriteImage(prd_itk, test_save_path + case + "_pred.nii.gz")
    # sitk.WriteImage(img_itk, test_save_path + case + "_img.nii.gz")
    # sitk.WriteImage(lab_itk, test_save_path + case + "_gt.nii.gz")
    return first_metric, second_metric, third_metric
def Inference(args,net,test_save_path):
    with open(args.root_path + '/test.list', 'r') as f:
        image_list = f.readlines()
    image_list = sorted([item.replace('\n', '').split(".")[0]
                         for item in image_list])
    # net.eval()
    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    for case in tqdm(image_list):
        first_metric, second_metric, third_metric = test_single_volume(
            case, net, test_save_path, args)
        first_total += np.asarray(first_metric)
        second_total += np.asarray(second_metric)
        third_total += np.asarray(third_metric)
    metric = [first_total / len(image_list), second_total /
                  len(image_list), third_total / len(image_list)]
    print(metric)
    print((metric[0] + metric[1] + metric[2]) / 3)
args = parser.parse_args()
if __name__ == "__main__":
    model_type = 'vit_b'
    checkpoint = 'work_dir/MedSAM/sam_vit_b_01ec64.pth'
    device = 'cuda:2'
    label_id = 1  # liver
    num_classes = 4

    medsam_model = sam_model = sam_model_registry[model_type](num_classes=num_classes, checkpoint=checkpoint).to(device)
    ckpoint = r"E:\2023\ssr\MedSAM-main\work_dir\ACDC\sam_model_best.pth"
    medsam_model .load_state_dict(torch.load(ckpoint))
    # medsam_model.load_state_dict(checkpoint["model"])
    # medsam_model = medsam_model.to(device)
    # medsam_model.eval()
    os.makedirs(args.seg_path, exist_ok=True)
    Inference(args, medsam_model, args.seg_path)