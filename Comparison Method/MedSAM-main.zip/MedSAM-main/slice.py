import os
import shutil

import os
import shutil


def copy_png_images_based_on_txt(txt_file_path, source_folder, target_folder):
    """
    根据txt文件中的图片名称（不包含扩展名），从源文件夹复制.png图片到目标文件夹。

    :param txt_file_path: 包含图片名称的txt文件路径
    :param source_folder: 包含所有图片的源文件夹路径
    :param target_folder: 要将图片复制到的目标文件夹路径
    """
    # 确保目标文件夹存在
    if not os.path.exists(target_folder):
        os.makedirs(target_folder)

    # 读取txt文件中的内容
    with open(txt_file_path, 'r', encoding='utf-8') as file:
        image_names = file.read().splitlines()  # 假设每行是一个图片名称（不包含扩展名）

    # 遍历源文件夹中的所有文件
    for file_name in os.listdir(source_folder):
        # 检查文件是否是PNG图片
        if file_name.lower().endswith('.png'):
            # 提取文件名（不包含扩展名）
            base_name = os.path.splitext(file_name)[0]
            # 如果文件名（不包含扩展名）在txt文件中提到的图片名称列表中
            if base_name in image_names:
                source_file_path = os.path.join(source_folder, file_name)
                target_file_path = os.path.join(target_folder, file_name)
                # 复制文件
                shutil.copy2(source_file_path, target_file_path)
                print(f"已复制图片：{file_name}")



# 示例用法
txt_file_path = r"D:\2024\ssr\DATA\fewdata\ACDC\train.txt"  # 替换为你的txt文件路径
source_folder = r'D:\2024\ssr\DATA\heart\train\mask'  # 替换为包含图片的源文件夹路径
target_folder = r'D:\2024\ssr\DATA\fewdata\ACDC\mask'  # 替换为目标文件夹路径

copy_png_images_based_on_txt(txt_file_path, source_folder, target_folder)