# -*- coding: utf-8 -*-
# %% load environment
import glob
import random
import re
import shutil
import time

import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

from torch.utils.data import DataLoader

from dataset import SegDataset
from metrics.metric import Metric

join = os.path.join
import torch
from segment_anything import sam_model_registry
from skimage import io, transform
import torch.nn.functional as F
import argparse


# visualization functions
# source: https://github.com/facebookresearch/segment-anything/blob/main/notebooks/predictor_example.ipynb
# change color to avoid red and green
def show_mask(mask, ax, random_color=False):
    if random_color:
        color = np.concatenate([np.random.random(3), np.array([0.6])], axis=0)
    else:
        color = np.array([251 / 255, 252 / 255, 30 / 255, 0.6])
    h, w = mask.shape[-2:]
    mask_image = mask.reshape(h, w, 1) * color.reshape(1, 1, -1)
    ax.imshow(mask_image)


def show_box(box, ax):
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(
        plt.Rectangle((x0, y0), w, h, edgecolor="blue", facecolor=(0, 0, 0, 0), lw=2)
    )


@torch.no_grad()
def medsam_inference(medsam_model, img_embed, box_1024, H, W):
    box_torch = torch.as_tensor(box_1024, dtype=torch.float, device=img_embed.device)
    if len(box_torch.shape) == 2:
        box_torch = box_torch[:, None, :]  # (B, 1, 4)

    sparse_embeddings, dense_embeddings = medsam_model.prompt_encoder(
        points=None,
        boxes=box_torch,
        masks=None,
    )
    low_res_logits, _ = medsam_model.mask_decoder(
        image_embeddings=img_embed,  # (B, 256, 64, 64)
        image_pe=medsam_model.prompt_encoder.get_dense_pe(),  # (1, 256, 64, 64)
        sparse_prompt_embeddings=sparse_embeddings,  # (B, 2, 256)
        dense_prompt_embeddings=dense_embeddings,  # (B, 256, 64, 64)
        multimask_output=False,
    )

    low_res_pred = torch.sigmoid(low_res_logits)  # (1, 1, 256, 256)

    low_res_pred = F.interpolate(
        low_res_pred,
        size=(H, W),
        mode="bilinear",
        align_corners=False,
    )  # (1, 1, gt.shape)
    low_res_pred = low_res_pred.squeeze().cpu().numpy()  # (256, 256)
    # medsam_seg = (low_res_pred > 0.5).astype(np.uint8) * 255  # Convert to 8-bit format
    return low_res_pred

# %% load model and image
parser = argparse.ArgumentParser(
    description="run inference on testing set based on MedSAM"
)
parser.add_argument(
    "-i",
    "--data_path",
    type=str,
    default=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image",
    help="path to the data folder",
)
parser.add_argument(
    "-o",
    "--seg_path",
    type=str,
    default=r"D:\2024\ssr\MedSAM-main",
    help="path to the segmentation folder",
)
parser.add_argument(
    "--box",
    type=list,
    default=[250, 250, 2350, 2350],
    help="bounding box of the segmentation target",
)
parser.add_argument("--device", type=str, default="cuda:0", help="device")
parser.add_argument(
    "-chk",
    "--checkpoint",
    type=str,
    default=r"D:\2024\ssr\MedSAM-main\work_dir\MedSAM\sam_vit_b_01ec64.pth",
    help="path to the trained model",
)
args = parser.parse_args()

device = args.device
# medsam_model = sam_model_registry["vit_b"](checkpoint=args.checkpoint)
def main(args):
    ckpoint = r"D:\2024\ssr\MedSAM-main\work_dir\Kavsir-SEG-20250522-1000\epoch_99.pth"
    medsam_model = sam_model_registry["vit_b"](num_classes=1, checkpoint=args.checkpoint).to(device)
    checkpoint = torch.load(ckpoint, map_location=device)
    medsam_model.load_state_dict(checkpoint["model"])

    # medsam_model.load_state_dict(torch.load(ckpoint))

    medsam_model = medsam_model.to(device)
    medsam_model.eval()
    metric = Metric(num_classes=2)
    # create output directory if not exists
    os.makedirs(args.seg_path, exist_ok=True)

    # get list of all images in the data_path
    image_files = [f for f in os.listdir(args.data_path) if os.path.isfile(os.path.join(args.data_path, f))]
    mask_paths = r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"

    bbox_shift = 20

    # img_path = r"D:\2024\ssr\DATA\CXR\train\image"
    # mask_path = r"D:\2024\ssr\DATA\CXR\train\mask"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\train\image"
    # mask_path =r"D:\2024\ssr\DATA\MoNuseg\train\mask"
    # img_path = r"D:\2024\ssr\DATA\CHASE\train\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\train\mask"
    # img_path=r"D:\2024\ssr\DATA\heart\train\image"
    # mask_path = r"D:\2024\ssr\DATA\heart\train\mask"
    img_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"

    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)

    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]

        # print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + (
            '.png' if os.path.splitext(file)[1].lower() == '.png' else '.gif')) for file in img_paths]
    else:
        bs = 1
        img_paths = [img_path]
        mask_paths = [mask_path]
        num_workers = 1
    pixel_mean = [0.5] * 3
    pixel_std = [0.5] * 3
    tr_dataset = SegDataset(img_paths, mask_paths=mask_paths, mask_divide=True,
                            divide_value=255,
                            pixel_mean=pixel_mean, pixel_std=pixel_std, img_size=1024)

    dataloader = DataLoader(tr_dataset, batch_size=1, shuffle=False, num_workers=1)
    test_save_path = r"D:\2024\ssr\MedSAM-main\Kavir_SEG"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    for i, sample in enumerate(dataloader):
        image, gt2D, boxes = sample['image'], sample['label'], sample['box']

        boxes_np = boxes.detach().cpu().numpy()
        image, gt2D = image.to(device), gt2D.to(device)
        # img_path = os.path.join(args.data_path, image_file)
        # gt_path = os.path.join(mask_paths, image_file)
        # img_np = io.imread(img_path)
        #
        # if len(img_np.shape) == 2:
        #     img_3c = np.repeat(img_np[:, :, None], 3, axis=-1)
        # else:
        #     img_3c = img_np
        #
        # H, W, _ = img_3c.shape
        #
        # # image preprocessing
        # img_1024 = transform.resize(
        #     img_3c, (1024, 1024), order=3, preserve_range=True, anti_aliasing=True
        # ).astype(np.uint8)
        # img_1024 = (img_1024 - img_1024.min()) / np.clip(
        #     img_1024.max() - img_1024.min(), a_min=1e-8, a_max=None
        # )  # normalize to [0, 1], (H, W, 3)
        #
        # # convert the shape to (3, H, W)
        # img_1024_tensor = (
        #     torch.tensor(img_1024).float().permute(2, 0, 1).unsqueeze(0).to(device)
        # )
        #
        # # 读取并处理标签
        #
        # gt = cv2.imread(gt_path, cv2.IMREAD_GRAYSCALE)  # single channel
        # assert gt is not None, f"Failed to read ground truth: {gt_path}"
        # gt = cv2.resize(gt, (1024, 1024), interpolation=cv2.INTER_NEAREST)  # resize 标签
        #
        # label_ids = np.unique(gt)[1:]  # 忽略背景
        # gt2D = np.uint8(gt == random.choice(label_ids.tolist()))  # (1024, 1024)
        #
        # assert np.max(gt2D) == 1 and np.min(gt2D) == 0.0, "ground truth should be 0, 1"
        #
        # y_indices, x_indices = np.where(gt2D > 0)
        # x_min, x_max = np.min(x_indices), np.max(x_indices)
        # y_min, y_max = np.min(y_indices), np.max(y_indices)
        #
        # # 添加随机扰动
        # H, W = gt2D.shape
        # x_min = max(0, x_min - random.randint(0, bbox_shift))
        # x_max = min(W, x_max + random.randint(0, bbox_shift))
        # y_min = max(0, y_min - random.randint(0, bbox_shift))
        # y_max = min(H, y_max + random.randint(0, bbox_shift))
        # bboxes = np.array([x_min, y_min, x_max, y_max])
        #
        #
        # box_np = np.array([bboxes])
        # # transfer box_np to 1024x1024 scale
        # box_1024 = box_np / np.array([W, H, W, H]) * 1024
        # times = []
        # start = time.time()
        # multimask_output=False
        # input_size = [1024, 1024]

        with torch.no_grad():

            image_embedding = medsam_model.image_encoder(image)
            out = medsam_inference(medsam_model, image_embedding, boxes_np, 1024, 1024)

        end = time.time()

        metric.update(torch.tensor(out).unsqueeze(0), torch.tensor(gt2D))
        out=torch.tensor(out).unsqueeze(0)
        pred = torch.max(out, dim=1)[1]


        # _, axs = plt.subplots(1, 2, figsize=(25, 25))
        # axs[0].imshow(pred.cpu().permute(1, 2, 0).detach().numpy(), cmap='gray')
        # axs[1].imshow(target.cpu().permute(1, 2, 0).detach().numpy(), cmap='gray')
        # plt.subplots_adjust(wspace=0.01, hspace=0)
        # filename = f"./test{i + 1}.png"
        # full_path = os.path.join(test_save_path, filename)
        # plt.savefig(full_path, bbox_inches="tight", dpi=300)
        # plt.close('all')

        predname = f"./pred{i + 1}.png"
        pred_path = os.path.join(test_save_path, predname)
        pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
        plt.figure(figsize=(10, 10))
        plt.imshow(pred_image, cmap='gray', interpolation='none')
        plt.axis('off')
        plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        plt.close('all')

        # save segmentation result
        # seg_result_path = os.path.join(args.seg_path, image_file)
        # io.imsave(seg_result_path, medsam_seg.astype(np.uint8), check_contrast=False)

    print("Segmentation results saved to:", args.seg_path)

    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))


if __name__ == '__main__':
    main(args)