import argparse
import glob
import logging
import os
import random
import re
import shutil
import sys

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
import torchvision.transforms.functional as TF
from pathlib import Path

from matplotlib import pyplot as plt
from torch import optim
from torch.utils.data import DataLoader, random_split
from tqdm import tqdm

import wandb
from dataset import testDataset
from evaluate import evaluate
from metrics.metric import Metric
from unet import UNet
from utils.data_loading import BasicDataset, CarvanaDataset
from utils.dice_score import dice_loss

dir_img = Path(r"D:\2024\ssr\DATA\CHASE\test\image")
dir_mask = Path(r"D:\2024\ssr\DATA\CHASE\test\mask")
dir_checkpoint = Path(r'D:\2024\ssr\Pytorch-UNet-master\model')


def test_model(
        model,
        device,
        test_save_path,
        img_scale: float = 0.5,

):
    # 1. Create dataset
    # try:
    #     test_dataset = CarvanaDataset(dir_img, dir_mask, img_scale)
    # except (AssertionError, RuntimeError, IndexError):
    #     test_dataset = BasicDataset(dir_img, dir_mask, img_scale)

    # # 2. Split into train / validation partitions
    # n_val = int(len(dataset) * val_percent)
    # n_train = len(dataset) - n_val
    # train_set, val_set = random_split(dataset, [n_train, n_val], generator=torch.Generator().manual_seed(0))

    # 3. Create data loaders
    #
    # from thop import profile, clever_format
    # import time
    # dummy_input = torch.randn(1, 3, 1024, 1024).cuda()
    # flops, params = profile(model, inputs=(dummy_input,), verbose=False)
    # flops, params = clever_format([flops, params], "%.3f")
    # print(f"FLOPs: {flops}, Params: {params}")
    #
    # # 计算 FPS 的代码
    # start_time = time.time()
    # for _ in range(100):
    #     with torch.no_grad():
    #         _ = model(dummy_input)
    # end_time = time.time()
    # fps = 100 / (end_time - start_time)
    # print(f"FPS: {fps:.2f}")
    img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    mask_path =r"D:\2024\ssr\DATA\CXR\test\mask"
    # img_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    # mask_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    # img_path =r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path =r"D:\2024\ssr\DATA\CHASE\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    # image = h5f['image'][:]
    # label = h5f['label'][:]
    test_dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)

    test_loader = DataLoader(test_dataset, shuffle=False, drop_last=True)
    metric = Metric(num_classes=2)
    i=0
    for batch in test_loader:

        images, true_masks = batch['image'], batch['label']
        images = images.to(device=device, dtype=torch.float32, memory_format=torch.channels_last)
        target = true_masks.to(device=device, dtype=torch.long)
        with torch.no_grad():
            out = model(images)
            metric.update(out, target)
            pred = torch.max(out, dim=1)[1]
            predname = f"./pred{i + 1}.png"
            pred_path = os.path.join(test_save_path, predname)
            pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
            plt.figure(figsize=(10, 10))
            plt.imshow(pred_image, cmap='gray', interpolation='none')
            plt.axis('off')
            plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
            plt.close('all')
        i = i + 1
    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))

def get_args():
    parser = argparse.ArgumentParser(description='Train the UNet on images and target masks')
    parser.add_argument('--epochs', '-e', metavar='E', type=int, default=300, help='Number of epochs')
    parser.add_argument('--batch-size', '-b', dest='batch_size', metavar='B', type=int, default=2, help='Batch size')
    parser.add_argument('--learning-rate', '-l', metavar='LR', type=float, default=1e-5,
                        help='Learning rate', dest='lr')
    parser.add_argument('--load', '-f', type=str, default=r"D:\2024\ssr\Pytorch-UNet-master\model\CXR\checkpoint_epoch300.pth", help='Load model from a .pth file')
    parser.add_argument('--scale', '-s', type=float, default=0.5, help='Downscaling factor of the images')
    parser.add_argument('--validation', '-v', dest='val', type=float, default=10.0,
                        help='Percent of the data that is used as validation (0-100)')
    parser.add_argument('--amp', action='store_true', default=False, help='Use mixed precision')
    parser.add_argument('--bilinear', action='store_true', default=False, help='Use bilinear upsampling')
    parser.add_argument('--classes', '-c', type=int, default=2, help='Number of classes')

    return parser.parse_args()


if __name__ == '__main__':
    import os
    os.environ["WANDB_API_KEY"] = "8315b85f27c76a7315935207cae98b2c28fe6688"
    os.environ["WANDB_MODE"] = "offline"

    args = get_args()

    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'Using device {device}')

    # Change here to adapt to your data
    # n_channels=3 for RGB images
    # n_classes is the number of probabilities you want to get per pixel
    model = UNet(n_channels=3, n_classes=args.classes, bilinear=args.bilinear)
    model = model.to(memory_format=torch.channels_last)


    if args.load:
        state_dict = torch.load(args.load, map_location=device)
        # del state_dict['mask_values']
        model.load_state_dict(state_dict)
        logging.info(f'Model loaded from {args.load}')

    model.to(device=device)
    test_save_path = r"D:\2024\ssr\Pytorch-UNet-master\outputs\CXR"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)

    test_model(
            model=model,
            device=device,
            test_save_path=test_save_path,
            img_scale=args.scale,

        )

