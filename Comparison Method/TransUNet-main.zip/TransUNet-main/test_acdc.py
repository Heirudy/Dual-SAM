import argparse
import logging
import os
import random
import shutil
import sys

import h5py
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
from matplotlib import pyplot as plt
from medpy import metric
from scipy.ndimage import zoom
from torch.utils.data import DataLoader
from tqdm import tqdm
import SimpleITK as sitk
from dataset_ACDC import ACDC_dataset

from networks.vit_seg_modeling import VisionTransformer as ViT_seg
from networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg
from PIL import Image
from albumentations import Compose, Resize, Normalize

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default=r"D:\2024\ssr\DATA\ACDC", help='Name of Experiment')  # for acdc volume_path=root_dir
parser.add_argument('--dataset', type=str,
                    default='ACDC', help='experiment_name')
parser.add_argument('--num_classes', type=int,
                    default=4, help='output channel of network')
parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')

parser.add_argument('--max_iterations', type=int, default=20000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int, default=300, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=4,
                    help='batch_size per gpu')
parser.add_argument('--img_size', type=int, default=512, help='input patch size of network input')
parser.add_argument('--is_savenii', action="store_true", help='whether to save results during inference')

parser.add_argument('--n_skip', type=int, default=3, help='using number of skip-connect, default is num')
parser.add_argument('--vit_name', type=str, default='R50-ViT-B_16', help='select one vit model')

parser.add_argument('--test_save_dir', type=str, default='../predictions', help='saving prediction as nii!')
parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=0.01, help='segmentation network learning rate')
parser.add_argument('--seed', type=int, default=1234, help='random seed')
parser.add_argument('--vit_patches_size', type=int, default=16, help='vit_patches_size, default is 16')
args = parser.parse_args()

def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    if pred.sum() != 0:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        print('bad')
        asd = -1
        hd95 = -1
    jc = metric.binary.jc(pred, gt)
    return dice, hd95, asd, jc


def test_single_volume(case, net, test_save_path, FLAGS):
    h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    image = h5f['image'][:]
    label = h5f['label'][:]
    prediction = np.zeros_like(label)
    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (512 / x, 512 / y), order=0)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():

            out_main = net(input)
            out = torch.argmax(torch.softmax(
                out_main, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            pred = zoom(out, (x / 512, y / 512), order=0)
            prediction[ind] = pred
        # 从 case 中提取患者编号和帧编号
        patient_id, frame_id = case.split("_")  # 假设 case 格式为 "patient003_frame01"

        # # 构造预测结果的文件名
        # pred_name = f"{patient_id}_{frame_id}_pred_{ind + 1}.png"
        # pred_path = os.path.join(test_save_path, pred_name)
        #
        # # 保存预测结果
        # plt.figure(figsize=(10, 10))
        # plt.imshow(pred, cmap='gray', interpolation='none')
        # plt.axis('off')
        # plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        # plt.close('all')
        patient_id, frame_id = case.split("_")
        base_dir = r'D:\2024\ssr\DATA\ACDC_or\database\training_renamed'
        patient_dir = os.path.join(base_dir, f"{patient_id}")
        new_file_name = f"{case}_gt.nii.gz"
        case_raw = os.path.join(patient_dir, new_file_name)
        # case_raw = r'D:\2024\ssr\DATA\ACDC_or\database\training' + case+ '.nii.gz'
        case_raw = sitk.ReadImage(case_raw)
        raw_spacing = case_raw.GetSpacing()
        raw_spacing_new = []
        raw_spacing_new.append(raw_spacing[2])
        raw_spacing_new.append(raw_spacing[1])
        raw_spacing_new.append(raw_spacing[0])
        raw_spacing = raw_spacing_new
        if test_save_path is not None:
            img_itk = sitk.GetImageFromArray(image.astype(np.float32))
            prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
            lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
            img_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
            prd_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
            lab_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
            sitk.WriteImage(prd_itk, test_save_path + '/' + case + "_pred.nii.gz")
            # sitk.WriteImage(img_itk, test_save_path + '/' + case + "_img.nii.gz")
            sitk.WriteImage(lab_itk, test_save_path + '/' + case + "_gt.nii.gz")
            print('saved successfully!')
    first_metric = calculate_metric_percase(prediction == 1, label == 1)
    second_metric = calculate_metric_percase(prediction == 2, label == 2)
    third_metric = calculate_metric_percase(prediction == 3, label == 3)


    return first_metric, second_metric, third_metric
def inference(args, net, test_save_path=None):
    with open(args.root_path + '/test.list', 'r') as f:
        image_list = f.readlines()
    image_list = sorted([item.replace('\n', '').split(".")[0]
                         for item in image_list])


    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)


    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    for case in tqdm(image_list):
        first_metric, second_metric, third_metric = test_single_volume(
            case, net, test_save_path, args)
        first_total += np.asarray(first_metric)
        second_total += np.asarray(second_metric)
        third_total += np.asarray(third_metric)
        avg_metric = [first_total / len(image_list), second_total /
                      len(image_list), third_total / len(image_list)]
    print(avg_metric)
    print((avg_metric[0] + avg_metric[1] + avg_metric[2]) / 3)
    return "Testing Finished!"


if __name__ == "__main__":

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    dataset_config = {
        'ACDC': {
            'Dataset': ACDC_dataset,
            'volume_path': '../data/Synapse/test_vol_h5',
            'list_dir': './lists/lists_Synapse',
            'num_classes': 4,
            'z_spacing': 1,
        },
    }
    dataset_name = args.dataset
    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.volume_path = dataset_config[dataset_name]['volume_path']
    args.Dataset = dataset_config[dataset_name]['Dataset']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.z_spacing = dataset_config[dataset_name]['z_spacing']
    args.is_pretrain = True

    # name the same snapshot defined in train script!
    # args.exp = 'TU_' + dataset_name + str(args.img_size)
    # snapshot_path = "../model/{}/{}".format(args.exp, 'TU')
    # snapshot_path = snapshot_path + '_pretrain' if args.is_pretrain else snapshot_path
    # snapshot_path += '_' + args.vit_name
    # snapshot_path = snapshot_path + '_skip' + str(args.n_skip)
    # snapshot_path = snapshot_path + '_vitpatch' + str(args.vit_patches_size) if args.vit_patches_size!=16 else snapshot_path
    # snapshot_path = snapshot_path + '_epo' + str(args.max_epochs) if args.max_epochs != 30 else snapshot_path
    # if dataset_name == 'ACDC':  # using max_epoch instead of iteration to control training duration
    #     snapshot_path = snapshot_path + '_' + str(args.max_iterations)[0:2] + 'k' if args.max_iterations != 30000 else snapshot_path
    # snapshot_path = snapshot_path+'_bs'+str(args.batch_size)
    # snapshot_path = snapshot_path + '_lr' + str(args.base_lr) if args.base_lr != 0.01 else snapshot_path
    # snapshot_path = snapshot_path + '_'+str(args.img_size)
    # snapshot_path = snapshot_path + '_s'+str(args.seed) if args.seed!=1234 else snapshot_path

    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip
    config_vit.patches.size = (args.vit_patches_size, args.vit_patches_size)
    if args.vit_name.find('R50') != -1:
        config_vit.patches.grid = (
        int(args.img_size / args.vit_patches_size), int(args.img_size / args.vit_patches_size))
    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()
    snapshot =r"D:\2024\ssr\TransUNet-main\model\TU_ACDC512\TU\iter_14800_dice_0.6638.pth"
    # if not os.path.exists(snapshot): snapshot = snapshot.replace('best_model', 'epoch_'+str(args.max_epochs-1))
    net.load_state_dict(torch.load(snapshot))
    # snapshot = os.path.join(snapshot_path, 'best_model.pth')
    # if not os.path.exists(snapshot): snapshot = snapshot.replace('best_model', 'epoch_'+str(args.max_epochs-1))
    # net.load_state_dict(torch.load(snapshot))
    # snapshot_name = snapshot_path.split('/')[-1]

    # log_folder = './test_log/test_log_' + args.exp
    # os.makedirs(log_folder, exist_ok=True)
    # logging.basicConfig(filename=log_folder + '/'+snapshot_name+".txt", level=logging.INFO, format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    # logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    # logging.info(str(args))
    # logging.info(snapshot_name)

    # if args.is_savenii:
    #     args.test_save_dir = '../predictions'
    #     test_save_path = os.path.join(args.test_save_dir, args.exp, snapshot_name)
    #     os.makedirs(test_save_path, exist_ok=True)
    # else:
    #     test_save_path = None
    test_save_path = r"D:\2024\ssr\TransUNet-main\ACDC\patient"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    inference(args, net, test_save_path)


