import torch
import torch.nn as nn
import numpy as np
import cv2

class SAMWithClassifier(nn.Module):
    def __init__(self, sam_model, classifier_model):
        super().__init__()
        self.image_encoder = sam_model.image_encoder
        self.prompt_encoder = sam_model.prompt_encoder
        self.mask_decoder = sam_model.mask_decoder
        self.classifier = classifier_model  # sklearn模型，需要包装

    def forward(self, x, point_coords=None, point_labels=None, box=None):
        """
        x: [B, 3, H, W] 输入图像tensor
        point_coords: [B, N, 2] 点坐标tensor，float，单位像素
        point_labels: [B, N] 点标签tensor，int
        box: [B, 4] 框坐标tensor，float，[x_min, y_min, x_max, y_max]
        """

        # 1. 图像编码
        image_embedding = self.image_encoder(x)  # [B, 256, H', W']

        # 2. prompt编码
        sparse_embeddings, dense_embeddings = self.prompt_encoder(
            point_coords=point_coords,
            point_labels=point_labels,
            boxes=box,
            batch_size=x.shape[0]
        )

        # 3. mask解码
        masks, _, _ = self.mask_decoder(
            image_embedding=image_embedding,
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=False
        )  # masks: [B, 1, H'', W'']

        # 4. 线性分类器处理：
        # 这里复刻你的逻辑，先把embedding展平，转numpy给 sklearn分类器预测概率
        # 但 sklearn不能直接在 forward 用，这里做个简易包装用torch操作模拟（只做示范）

        # flatten embedding: [B, 256, H', W'] -> [B, 256, N], N=H'*W'
        B, C, H_, W_ = image_embedding.shape
        emb_flat = image_embedding.view(B, C, -1).permute(0, 2, 1).contiguous()  # [B, N, C]

        # 只处理 batch=1 的情况（thop测试时一般batch=1）
        emb_np = emb_flat[0].cpu().detach().numpy()  # [N, C]
        # 这里调用 sklearn分类器的 predict_proba
        class_probs = self.classifier.predict_proba(emb_np)  # [N, num_classes]

        # 转回 tensor [N, num_classes]
        class_probs_tensor = torch.tensor(class_probs, device=x.device)

        # 你可以reshape或直接返回
        # 例如返回SAM的mask + 分类器预测概率
        return masks, class_probs_tensor

# --------------------------------------------------------
# 下面是示范如何调用thop profile计算

if __name__ == "__main__":
    from segment_anything import sam_model_registry
    from thop import profile

    # 加载sam和sklearn分类器（示例）
    sam = sam_model_registry["vit_b"](checkpoint=r"D:\2024\ssr\SP-SAM\checkpoints\sam_vit_b_01ec64.pth").cuda()
    sam.eval()

    import joblib
    classifier = joblib.load("linear_classifier.pkl")  # 你训练好的sklearn线性模型

    model = SAMWithClassifier(sam, classifier).cuda()
    model.eval()

    # 构造dummy输入
    dummy_img = torch.randn(1, 3, 512, 512).cuda()

    # 构造dummy prompt
    dummy_point_coords = torch.tensor([[[256.0, 256.0]]]).cuda()  # [B=1, N=1, 2]
    dummy_point_labels = torch.tensor([[1]]).cuda()               # [B=1, N=1]
    dummy_box = torch.tensor([[100.0, 100.0, 400.0, 400.0]]).cuda()

    # profile计算FLOPs和参数
    macs, params = profile(
        model,
        inputs=(dummy_img, dummy_point_coords, dummy_point_labels, dummy_box),
        verbose=False
    )
    print(f"总FLOPs: {macs*2/1e9:.2f} GFLOPs")
    print(f"总参数: {params/1e6:.2f} M")
