import glob
import re
import shutil

import cv2
import numpy
import torch
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
import os
import random

from thop import profile
from torch.utils.data import DataLoader
from tqdm import tqdm
from dataset import SegDataset, TwoStreamBatchSampler, testDataset
from metrics.metric import Metric
from segment_anything import SamAutomaticMaskGenerator, sam_model_registry, SamPredictor
import argparse
from utils.utils import *
import time


def get_embedding(img, predictor):
    predictor.set_image(img)
    img_emb = predictor.get_image_embedding()

    return img_emb


def train(args, predictor, trainloader):
    # data_path = args.data_path
    # assert os.path.exists(data_path), 'data path does not exist!'

    num_image = args.k

    image_embeddings = []
    labels = []

    # get the image embeddings
    print('Start training...')
    t1 = time.time()
    i = 0
    for i, sampled_batch in enumerate(trainloader):
        # image = train_images[i]
        # mask = train_masks[i]
        image, mask = sampled_batch['image'].squeeze(0), sampled_batch['label'].squeeze(0)
        # image = torch.cat([image] * 3, dim=0)
        image = image.cpu().numpy()
        mask = mask.cpu().numpy()
        downsampled_mask = cv2.resize(mask, dsize=(64, 64), interpolation=cv2.INTER_NEAREST)

        img_emb = get_embedding(image, predictor)
        img_emb = img_emb.cpu().numpy().transpose((2, 3, 1, 0)).reshape((64, 64, 256)).reshape(-1, 256)
        image_embeddings.append(img_emb)

        labels.append(downsampled_mask.flatten())

        i += 1
        if i >= num_image:
            break

    t2 = time.time()
    print("Time used: {}m {}s".format((t2 - t1) // 60, (t2 - t1) % 60))

    image_embeddings_cat = np.concatenate(image_embeddings)
    labels = np.concatenate(labels)

    # Create a linear regression model and fit it to the training data
    model = LogisticRegression(max_iter=1000)
    model.fit(image_embeddings_cat, labels)

    return model


def load_data(data_path, train_fnames, test_fnames):
    train_images = []
    train_masks = []
    test_images = []
    test_masks = []

    # 读取训练集数据
    for fname in tqdm(train_fnames):
        image = cv2.imread(os.path.join(data_path, 'images', fname))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        mask = cv2.imread(os.path.join(data_path, 'masks', fname))
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(mask, 128, 1, cv2.THRESH_BINARY)
        train_images.append(image)
        train_masks.append(mask)

    # 读取测试集数据
    for fname in tqdm(test_fnames):
        image = cv2.imread(os.path.join(data_path, 'images', fname))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        mask = cv2.imread(os.path.join(data_path, 'masks', fname))
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(mask, 128, 1, cv2.THRESH_BINARY)
        test_images.append(image)
        test_masks.append(mask)

    return train_images, train_masks, test_images, test_masks


def test_visualize(args, model, predictor, testloader):
    num_visualize = args.visualize_num
    dice_linear = []
    dice1 = []
    dice2 = []
    dice3 = []
    metric = Metric(num_classes=2)
    test_save_path=r"D:\2024\ssr\SP-SAM\Kavsir-SEG\SP-SA"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)

    # # --- 先构造dummy输入 ---
    # dummy_input = torch.randn(3,1024, 1024).cuda()
    # dummy_input_batch = dummy_input.unsqueeze(0)  # [1, 3, 512, 512]
    #
    # dummy_point_coords = torch.tensor([[[256.0, 256.0]]], device="cuda")  # 1个batch，1个点，[B, N, 2]
    # dummy_point_labels = torch.tensor([[1]], device="cuda")  # [B, N]
    # dummy_box = torch.tensor([[100.0, 100.0, 400.0, 400.0]], device="cuda")  # [B, 4]
    # import torch.nn as nn
    # # --- 定义封装模型 ---
    # class SAMWithClassifier(nn.Module):
    #     def __init__(self, sam_model, classifier_model):
    #         super().__init__()
    #         self.image_encoder = sam_model.image_encoder
    #         self.prompt_encoder = sam_model.prompt_encoder
    #         self.mask_decoder = sam_model.mask_decoder
    #         self.classifier = classifier_model  # sklearn模型
    #
    #     def forward(self, x, point_coords=None, point_labels=None, box=None):
    #         # 1. 图像编码
    #         image_embedding = self.image_encoder(x)  # [B, 256, H', W']
    #
    #         # 2. prompt编码
    #         sparse_embeddings, dense_embeddings = self.prompt_encoder(
    #             point_coords=point_coords,
    #             point_labels=point_labels,
    #             boxes=box,
    #             batch_size=x.shape[0]
    #         )
    #
    #         # 3. mask解码
    #         masks, _, _ = self.mask_decoder(
    #             image_embedding=image_embedding,
    #             sparse_prompt_embeddings=sparse_embeddings,
    #             dense_prompt_embeddings=dense_embeddings,
    #             multimask_output=False
    #         )  # masks: [B, 1, H'', W'']
    #
    #         # 4. 线性分类器预测
    #         B, C, H_, W_ = image_embedding.shape
    #         emb_flat = image_embedding.view(B, C, -1).permute(0, 2, 1).contiguous()  # [B, N, C]
    #
    #         # 目前仅支持batch=1，sklearn模型使用numpy数组预测
    #         emb_np = emb_flat[0].cpu().detach().numpy()  # [N, C]
    #         class_probs = self.classifier.predict_proba(emb_np)  # [N, num_classes]
    #
    #         class_probs_tensor = torch.tensor(class_probs, device=x.device)
    #
    #         return masks, class_probs_tensor
    #
    # # --- 包装原来的model和predictor ---
    # wrapped_model = SAMWithClassifier(predictor.model, model).cuda()
    # wrapped_model.eval()
    #
    # # --- 计算 FLOPs 和参数 ---
    # macs, params = profile(
    #     wrapped_model,
    #     inputs=(dummy_input_batch, dummy_point_coords, dummy_point_labels, dummy_box),
    #     verbose=False
    # )
    # print(f"总FLOPs: {macs * 2 / 1e9:.2f} GFLOPs")
    # print(f"总参数: {params / 1e6:.2f} M")
    #
    # # --- 测试FPS ---
    # start_time = time.time()
    # with torch.no_grad():
    #     for _ in range(100):
    #         _ = wrapped_model(dummy_input_batch, dummy_point_coords, dummy_point_labels, dummy_box)
    # end_time = time.time()
    # fps = 100 / (end_time - start_time)
    # print(f"FPS: {fps:.2f}")


    for i, sample in enumerate(testloader):  # We loop over the test set directly
        # image = sample['image']
        # mask = sample['label']
        image, mask = sample['image'].squeeze(0), sample['label'].squeeze(0)
        image = image.cpu().numpy()
        mask = mask.cpu().numpy()
        H, W, _ = image.shape

        # get the image embedding and flatten it
        img_emb = get_embedding(image, predictor)
        img_emb = img_emb.cpu().numpy().transpose((2, 3, 1, 0)).reshape((64, 64, 256)).reshape(-1, 256)

        # get the mask predicted by the linear classifier
        y_pred = model.predict(img_emb)
        y_pred = y_pred.reshape((64, 64))
        # mask predicted by the linear classifier
        mask_pred_l = cv2.resize(y_pred, (mask.shape[1], mask.shape[0]), interpolation=cv2.INTER_NEAREST)

        # use distance transform to find a point inside the mask
        fg_point = get_max_dist_point(mask_pred_l)
        # Define the kernel for dilation
        kernel = np.ones((5, 5), np.uint8)
        eroded_mask = cv2.erode(mask_pred_l, kernel, iterations=3)
        mask_pred_l = cv2.dilate(eroded_mask, kernel, iterations=5)

        # set the image to sam
        predictor.set_image(image)

        # prompt the sam with the point
        input_point = np.array([[fg_point[0], fg_point[1]]])
        input_label = np.array([1])
        masks_pred_sam_prompted1, _, _ = predictor.predict(
            point_coords=input_point,
            point_labels=input_label,
            box=None,
            multimask_output=False,
        )

        # prompt the sam with the bounding box
        y_indices, x_indices = np.where(mask_pred_l > 0)
        if np.all(mask_pred_l == 0):
            bbox = np.array([0, 0, H, W])
        else:
            x_min, x_max = np.min(x_indices), np.max(x_indices)
            y_min, y_max = np.min(y_indices), np.max(y_indices)
            H, W = mask_pred_l.shape
            x_min = max(0, x_min - np.random.randint(0, 20))
            x_max = min(W, x_max + np.random.randint(0, 20))
            y_min = max(0, y_min - np.random.randint(0, 20))
            y_max = min(H, y_max + np.random.randint(0, 20))
            bbox = np.array([x_min, y_min, x_max, y_max])
        masks_pred_sam_prompted2, _, _ = predictor.predict(
            point_coords=None,
            point_labels=None,
            box=bbox[None, :],
            multimask_output=False, )

        # prompt the sam with both the point and bounding box
        masks_pred_sam_prompted3, _, _ = predictor.predict(
            point_coords=input_point,
            point_labels=input_label,
            box=bbox[None, :],
            multimask_output=False, )


        dice_l = dice_coef(mask, mask_pred_l)
        dice_p = dice_coef(mask, masks_pred_sam_prompted1[0])
        dice_b = dice_coef(mask, masks_pred_sam_prompted2[0])
        dice_i = dice_coef(mask, masks_pred_sam_prompted3[0])
        dice_linear.append(dice_l)
        dice1.append(dice_p)
        dice2.append(dice_b)
        dice3.append(dice_i)
        target = torch.from_numpy(mask)
        out= torch.from_numpy(masks_pred_sam_prompted3[0])
        metric.update(out, target)

        pred = out
        # predname = f"./pred{i + 1}.png"
        # pred_path = os.path.join(test_save_path, predname)
        # pred_image = pred.cpu().detach().numpy()
        # plt.figure(figsize=(10, 10))
        # plt.imshow(pred_image, cmap='gray', interpolation='none')
        # plt.axis('off')
        # plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        # plt.close('all')
        # # plot the results
        # fig, ax = plt.subplots(1, 1, figsize=(10, 10))  # Only one plot now
        # ax.imshow(masks_pred_sam_prompted3[0])  # Show the mask predicted with point + box
        # ax.set_axis_off()  # Hide axis
        #
        # if not os.path.exists(args.save_path):
        #     os.mkdir(args.save_path)
        # plt.savefig(os.path.join(args.save_path, f"result_{i}_point_box.png"))

    mdice0 = round(sum(dice_linear) / len(dice_linear), 5)
    mdice1 = round(sum(dice1) / len(dice1), 5)
    mdice2 = round(sum(dice2) / len(dice2), 5)
    mdice3 = round(sum(dice3) / len(dice3), 5)

    print('For the first {} images: '.format(num_visualize))
    print('mdice(linear classifier: )', mdice0)
    print('mDice(point prompts): ', mdice1)
    print('mDice(bbox prompts): ', mdice2)
    print('mDice(points and boxes): ', mdice3)
    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))

def test(args, predictor):
    data_path = args.data_path
    images = []
    masks = []
    fnames = os.listdir(os.path.join(data_path, 'images'))
    print(f'loading images from {data_path}...')
    for fname in tqdm(fnames):
        # read data
        image = cv2.imread(os.path.join(data_path, 'images', fname))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        mask = cv2.imread(os.path.join(data_path, 'masks', fname))
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(mask, 128, 1, cv2.THRESH_BINARY)
        images.append(image)
        masks.append(mask)

    kf = KFold(n_splits=1, shuffle=False, random_state=42)
    for train_index, text_index in kf.split(images):
        train_images = [images[i] for i in train_index]
        train_masks = [masks[i] for i in train_index]
        test_images = [images[i] for i in text_index]
        test_masks = [masks[i] for i in text_index]

        # train the linear classifier
        k = args.k
        random_indices = random.sample(range(len(train_images)), k)
        image_embeddings = []
        labels = []
        for idx in random_indices:
            image = train_images[idx]
            mask = train_masks[idx]
            downsampled_mask = cv2.resize(mask, dsize=(64, 64), interpolation=cv2.INTER_NEAREST)

            img_emb = get_embedding(image)
            img_emb = img_emb.cpu().numpy().transpose((2, 3, 1, 0)).reshape((64, 64, 256)).reshape(-1, 256)
            image_embeddings.append(img_emb)
            labels.append(downsampled_mask.flatten())

        image_embeddings_cat = numpy.concatenate(image_embeddings)
        labels = numpy.concatenate(labels)

        model = LogisticRegression(max_iter=1000)  # how to set parameters?? C, max_iter, verbose, solver
        model.fit(image_embeddings_cat, labels)

        # test
        dice_linear = []
        dice1 = []
        dice2 = []
        dice3 = []



        for idx in range(len(test_images)):
            image = test_images[idx]
            mask = test_masks[idx]
            H, W, _ = image.shape

            img_emb = get_embedding(image)
            img_emb = img_emb.cpu().numpy().transpose((2, 3, 1, 0)).reshape((64, 64, 256)).reshape(-1, 256)

            # ger the mask predicted by the linear classifier
            y_pred = model.predict(img_emb)
            y_pred = y_pred.reshape((64, 64))
            mask_pred_l = cv2.resize(y_pred, (mask.shape[1], mask.shape[0]), interpolation=cv2.INTER_NEAREST)

            # use distance transform to find a point inside the mask
            fg_point = get_max_dist_point(mask_pred_l)

            # Define the kernel for dilation
            kernel = np.ones((5, 5), np.uint8)

            eroded_mask = cv2.erode(mask_pred_l, kernel, iterations=3)
            mask_pred_l = cv2.dilate(eroded_mask, kernel, iterations=5)

            # set the image to sam
            predictor.set_image(image)

            # prompt sam with the point
            input_point = np.array([[fg_point[0], fg_point[1]]])
            input_label = np.array([1])
            masks_pred_sam_prompted1, _, logits = predictor.predict(
                point_coords=input_point,
                point_labels=input_label,
                box=None,
                multimask_output=False, )

            # prompt sam with the bbox
            y_indices, x_indices = np.where(mask_pred_l > 0)
            if np.all(mask_pred_l == 0):
                bbox = np.array([0, 0, H, W])
            else:
                x_min, x_max = np.min(x_indices), np.max(x_indices)
                y_min, y_max = np.min(y_indices), np.max(y_indices)
                H, W = mask_pred_l.shape
                x_min = max(0, x_min - np.random.randint(0, 20))
                x_max = min(W, x_max + np.random.randint(0, 20))
                y_min = max(0, y_min - np.random.randint(0, 20))
                y_max = min(H, y_max + np.random.randint(0, 20))
                bbox = np.array([x_min, y_min, x_max, y_max])
                masks_pred_sam_prompted2, _, _ = predictor.predict(
                    point_coords=None,
                    point_labels=None,
                    box=bbox[None, :],
                    multimask_output=False, )

                masks_pred_sam_prompted3, _, _, = predictor.predict(
                    point_coords=input_point,
                    point_labels=input_label,
                    box=bbox[None, :],
                    multimask_output=False, )

                dice_l = dice_coef(mask, mask_pred_l)
                dice_p = dice_coef(mask, masks_pred_sam_prompted1[0])
                dice_b = dice_coef(mask, masks_pred_sam_prompted2[0])
                dice_c = dice_coef(mask, masks_pred_sam_prompted3[0])
                dice_linear.append(dice_l)
                dice1.append(dice_p)
                dice2.append(dice_b)
                dice3.append(dice_c)

        mdice0 = round(sum(dice_linear) / float(len(dice_linear)), 5)
        mdice1 = round(sum(dice1) / float(len(dice1)), 5)
        mdice2 = round(sum(dice2) / float(len(dice2)), 5)
        mdice3 = round(sum(dice3) / float(len(dice3)), 5)

        print('mdice(linear classifier: )', mdice0)
        print('mDice(point prompts): ', mdice1)
        print('mDice(bbox prompts): ', mdice2)
        print('mDice(points and boxes): ', mdice3)
        print('\n')


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('--device', type=str, default='cuda:0', help='device')
    parser.add_argument('--k', type=int, default=2, help='number of pics')
    parser.add_argument('--data_path', type=str, default=r'D:\2023\ggl\Kvasir-SEG1\Kvasir-SEG',
                        help='path to train data')
    parser.add_argument('--model_type', type=str, default='vit_b', help='SAM model type')
    parser.add_argument('--checkpoint', type=str,
                        default='checkpoints/sam_vit_b_01ec64.pth',
                        help='SAM checkpoint')
    parser.add_argument('--visualize', type=bool, default=True, help='visualize the results')
    parser.add_argument('--save_path', type=str, default='./results', help='path to save the results')
    parser.add_argument('--visualize_num', type=int, default=8, help='number of pics to visualize')
    args = parser.parse_args()

    # set random seed
    random.seed(42)

    # register the SAM model
    sam = sam_model_registry[args.model_type](checkpoint=args.checkpoint).to(args.device)
    global predictor
    predictor = SamPredictor(sam)
    print('SAM model loaded!', '\n')

    # img_path = r"D:\2024\ssr\DATA\lung\train\image"
    # mask_path = r"D:\2024\ssr\DATA\lung\train\mask"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\train\image"
    # mask_path =r"D:\2024\ssr\DATA\MoNuseg\train\mask"
    img_path = r"D:\2024\ssr\DATA\vessel\train\image"
    mask_path = r"D:\2024\ssr\DATA\vessel\train\mask"
    # img_path = r"D:\2024\ssr\DATA\fewdata\Kavsir-SEGs\image"
    # mask_path = r"D:\2024\ssr\DATA\fewdata\Kavsir-SEGs\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)

    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]

        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + (
            '.png' if os.path.splitext(file)[1].lower() == '.png' else '.gif')) for file in img_paths]
    else:
        bs = 1
        img_paths = [img_path]
        mask_paths = [mask_path]
        num_workers = 1
    pixel_mean = [0.5] * 3
    pixel_std = [0.5] * 3
    db_train = SegDataset(img_paths, mask_paths=mask_paths, mask_divide=True,
                          divide_value=255,
                           img_size=1024)

    # total_slices = len(db_train)
    # labeled_slice =2
    # print("Total silices is: {}, labeled slices is: {}".format(total_slices, labeled_slice))
    # labeled_idxs = list(range(0, labeled_slice))
    # unlabeled_idxs = list(range(labeled_slice, total_slices))
    # batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs,2, 2 - 1)
    # print("The length of train set is: {}".format(len(db_train)))


    trainloader = DataLoader(db_train, num_workers=8, pin_memory=True,)

    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask"
    img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    # mask_path = r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)
    testloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)
    # # 手动指定训练集和测试集文件名
    # train_fnames = ['image5.jpg', 'image2.jpg', 'image3.jpg']  # 训练集文件名列表
    # test_fnames = ['image1.jpg', 'image5.jpg']  # 测试集文件名列表

    # # 加载训练集和测试集
    # train_images, train_masks, test_images, test_masks = load_data(args.data_path, train_fnames, test_fnames)

    if args.visualize:
        model = train(args, predictor, trainloader)
        test_visualize(args, model, predictor, testloader)
    else:
        test(args, predictor)


if __name__ == '__main__':
    main()