import argparse
import os
import shutil
from einops import repeat
import h5py
import nibabel as nib
import numpy as np
import SimpleITK as sitk
import torch
from matplotlib import pyplot as plt
from medpy import metric
from scipy.ndimage import zoom
from scipy.ndimage.interpolation import zoom
from tqdm import tqdm

from core.networks import MTNet

# from networks.efficientunet import UNet


parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default=r"D:\2024\ssr\DATA\ACDC", help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='ACDC/Uncertainty_Rectified_Pyramid_Consistency', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='unet_urpc', help='model_name')
parser.add_argument('--num_classes', type=int,  default=4,
                    help='output channel of network')
parser.add_argument('--labeled_num', type=int, default=1,
                    help='labeled data')


def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    if pred.sum() != 0:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        print('bad')
        asd = -1
        hd95 = -1
    jc = metric.binary.jc(pred, gt)
    return dice, hd95, asd, jc


def test_single_volume(case, net, test_save_path, FLAGS):
    h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    image = h5f['image'][:]
    label = h5f['label'][:]
    prediction = np.zeros_like(label)

    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (512 / x, 512 / y), order=0)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        input = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)
        net.eval()
        with torch.no_grad():

            out_main = net(input)
            out = torch.argmax(torch.softmax(
                out_main, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            pred = zoom(out, (x / 512, y / 512), order=0)
            prediction[ind] = pred

        # 从 case 中提取患者编号和帧编号
        patient_id, frame_id = case.split("_")  # 假设 case 格式为 "patient003_frame01"

        # # 构造预测结果的文件名
        # pred_name = f"{patient_id}_{frame_id}_pred_{ind + 1}.png"
        # pred_path = os.path.join(test_save_path, pred_name)
        #
        # # 保存预测结果
        # plt.figure(figsize=(10, 10))
        # plt.imshow(pred, cmap='gray', interpolation='none')
        # plt.axis('off')
        # plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
        # plt.close('all')

    first_metric = calculate_metric_percase(prediction == 1, label == 1)
    second_metric = calculate_metric_percase(prediction == 2, label == 2)
    third_metric = calculate_metric_percase(prediction == 3, label == 3)

    patient_id, frame_id = case.split("_")
    base_dir = r'D:\2024\ssr\DATA\ACDC_or\database\training_renamed'
    patient_dir = os.path.join(base_dir, f"{patient_id}")
    new_file_name = f"{case}_gt.nii.gz"
    case_raw = os.path.join(patient_dir, new_file_name)
    # case_raw = r'D:\2024\ssr\DATA\ACDC_or\database\training' + case+ '.nii.gz'
    case_raw = sitk.ReadImage(case_raw)
    raw_spacing = case_raw.GetSpacing()
    raw_spacing_new = []
    raw_spacing_new.append(raw_spacing[2])
    raw_spacing_new.append(raw_spacing[1])
    raw_spacing_new.append(raw_spacing[0])
    raw_spacing = raw_spacing_new
    if test_save_path is not None:
        img_itk = sitk.GetImageFromArray(image.astype(np.float32))
        prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
        lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
        img_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
        prd_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
        lab_itk.SetSpacing((raw_spacing[2], raw_spacing[1], raw_spacing[0]))
        sitk.WriteImage(prd_itk, test_save_path + '/' + case + "_pred.nii.gz")
        # sitk.WriteImage(img_itk, test_save_path + '/' + case + "_img.nii.gz")
        sitk.WriteImage(lab_itk, test_save_path + '/' + case + "_gt.nii.gz")
        print('saved successfully!')
    return first_metric, second_metric, third_metric


def Inference(FLAGS):
    with open(FLAGS.root_path + '/test.list', 'r') as f:
        image_list = f.readlines()
    image_list = sorted([item.replace('\n', '').split(".")[0]
                         for item in image_list])
    snapshot_path = "../model/{}_{}_labeled/{}".format(
        FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
    test_save_path = "../model/{}_{}_labeled/{}_predictions/".format(
        FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    model = MTNet("resnet50", num_classes=4, use_group_norm=True,train=False)
    # model = torch.nn.DataParallel(model, device_ids='0').cuda()


    ckpt = torch.load(r"D:\2024\ssr\CDMA-main\ckpoint\ACDC\acdc_best_model1.pth")
    model.load_state_dict(ckpt)
    model.cuda()
    model.eval()


    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    test_save_path=r"D:\2024\ssr\CDMA-main\ACDC\patient"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    for case in tqdm(image_list):
        first_metric, second_metric, third_metric = test_single_volume(
            case, model, test_save_path, FLAGS)
        first_total += np.asarray(first_metric)
        second_total += np.asarray(second_metric)
        third_total += np.asarray(third_metric)
    avg_metric = [first_total / len(image_list), second_total /
                  len(image_list), third_total / len(image_list)]
    return avg_metric


if __name__ == '__main__':
    FLAGS = parser.parse_args()
    metric = Inference(FLAGS)
    print(metric)
    print((metric[0]+metric[1]+metric[2])/3)
