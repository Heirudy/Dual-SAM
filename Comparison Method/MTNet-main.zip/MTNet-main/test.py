import argparse
import glob
import os
import random
import re
import shutil
import time
import sys
from PIL import Image
from matplotlib import pyplot as plt
from tqdm import tqdm
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
Image.MAX_IMAGE_PIXELS = None
from metrics.metric import Metric

Image.MAX_IMAGE_PIXELS = None
# join = os.path.join
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader
import torch.nn.functional as F
import monai
import torch.optim as optim
from dataloaders.dataset import get_train_loader, get_val_loader, get_val_WSI_loader
from monai.data import decollate_batch, PILReader
from monai.inferers import sliding_window_inference
from utils.Metrics import DiceMetric
from utils.losses import DiceLoss, KDLoss, entropy_loss
import logging
from core.networks import MTNet
from tensorboardX import SummaryWriter
from dataset import SegDataset,TwoStreamBatchSampler
from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip
import torch
from fvcore.nn import FlopCountAnalysis, parameter_count


# 计算模型的参数数量
def count_params(model):
    params = sum(p.numel() for p in model.parameters())
    print(f"Total Params: {params / 1e6:.2f} M")  # 输出单位为百万（M）


# 计算模型的 FLOPs
def count_flops(model, input_tensor):
    flops = FlopCountAnalysis(model, input_tensor)
    print(f"FLOPs: {flops.total()}")  # 输出总的 FLOPs


# 计算 FPS
def calculate_fps(model, input_tensor, num_iterations=100):
    model.eval()
    start_time = time.time()

    for _ in range(num_iterations):
        with torch.no_grad():
            model(input_tensor)

    end_time = time.time()
    avg_time_per_iter = (end_time - start_time) / num_iterations
    fps = 1 / avg_time_per_iter
    print(f"FPS: {fps:.2f}")


class testDataset:
    def __init__(self, img_paths, mask_paths,


                 mask_divide=False, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=1024) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size

        # self.bbox_shift = bbox_shift

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        img = Image.open(img_path).convert("RGB")
        # img = tf.imread(img_path)
        mask = Image.open(mask_path).convert("L")

        img = np.asarray(img)
        mask = np.asarray(mask)
        if self.mask_divide:
            mask = mask // self.divide_value
        # sample = {"image": img, "label": mask}
        # if None not in (self.ops_weak, self.ops_strong):
        #         sample = self.transform(sample, self.ops_weak, self.ops_strong)
        # else:
        #         sample = self.transform(sample)
        transform = Compose(
            [
                # ColorJitter(),
                # VerticalFlip(),
                # HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )

        aug_data = transform(image=img,mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        sample = {"image": torch.from_numpy(x), "label": torch.from_numpy(target)}
        # sample = {"image": x, "label": target}
        return sample
def validate(model, val_loader):
    # model.eval()
    dice_metric = DiceMetric(num_class=2)
    metric = Metric(num_classes=2)
    test_save_path=r"D:\2024\ssr\CDMA-main\Kavsir-SEG\MTNet"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)

    sample_input = torch.randn(1, 3, 1024, 1024).cuda()  # 1 张图像，大小 1024x1024

    # 计算参数量、FLOPs 和 FPS
    count_params(model)
    count_flops(model, sample_input)
    calculate_fps(model, sample_input)

    with torch.no_grad():
        for i, sample in  enumerate(val_loader):
            val_images, target = sample["image"].cuda(), sample["label"].cuda()
            val_outputs1= model(val_images)
            val_outputs = val_outputs1
            out = torch.softmax(val_outputs, dim=1)
            metric.update(out, target)

            pred = torch.max(out, dim=1)[1]
            predname = f"./pred{i + 1}.png"
            pred_path = os.path.join(test_save_path, predname)
            pred_image = pred.cpu().permute(1, 2, 0).detach().numpy()
            plt.figure(figsize=(10, 10))
            plt.imshow(pred_image, cmap='gray', interpolation='none')
            plt.axis('off')
            plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
            plt.close('all')


            # dice_metric.add_batch(val_outputs,val_labels[:,0,:,:])
    # dice_value = dice_metric.compute_dice()
    # print(dice_value)
    # return dice_value
    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))



def main():
    save_folder = r'D:\2024\ssr\CDMA-main\save_folder'
    # img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\FIVES\test\Original"
    # mask_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # prompt_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # img_path = r"D:\2024\ssr\DATA\STARE\Images"
    # mask_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # prompt_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image\CXR_4"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # prompt_path = r"D:\2024\ssr\DATA\CXR\test\mask\CXR_4"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\image"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\images"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\test\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path =r"D:\2024\ssr\DATA\CXR\test\mask"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    # label = h5f['label'][:]
    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)
    testloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)
    # test_WSI_data_root = '/mnt/data2/lanfz/datasets/digestpath2019/tissue-test/'
    # test_WSI_files = get_files(test_WSI_data_root)
    # test_WSI_loader = get_val_WSI_loader(test_WSI_files, args)

    test_model = MTNet("resnet50", num_classes=2, use_group_norm=True, train=False).cuda()
    test_model.eval()
    ckpt = torch.load(r"D:\2024\ssr\CDMA-main\ckpoint\Kavsir-SEG\model_epoch_30.pth", map_location="cpu")
    test_model.load_state_dict(ckpt, strict=True)
    validate(test_model, testloader)


if __name__ == '__main__':
    main()