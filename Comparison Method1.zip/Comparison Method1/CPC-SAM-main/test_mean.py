# ensemble
import glob
import os
import re
import shutil
import sys
from tqdm import tqdm
import logging
import numpy as np
import argparse
import random
import numpy as np
import torch
from torch.utils.data import DataLoader
import torch.backends.cudnn as cudnn

from metrics.metric import Metric
from utils import test_single_image
from importlib import import_module
from segment_anything import sam_model_registry
from datasets.dataset_ACDC import ACDC_dataset
import h5py
from icecream import ic
import pandas as pd
from albumentations import Compose, Resize, Normalize

from PIL import Image
class testDataset:
    def __init__(self, img_paths, mask_paths,


                 mask_divide=False, divide_value=255,
                 pixel_mean=[0.5] * 3, pixel_std=[0.5] * 3,
                 img_size=1024) -> None:
        self.img_paths = img_paths
        self.mask_paths = mask_paths
        self.length = len(img_paths)
        self.mask_divide = mask_divide
        self.divide_value = divide_value
        self.pixel_mean = pixel_mean
        self.pixel_std = pixel_std
        self.img_size = img_size

        # self.bbox_shift = bbox_shift

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        img_path = self.img_paths[index]
        mask_path = self.mask_paths[index]
        img = Image.open(img_path).convert("RGB")
        # img = tf.imread(img_path)
        mask = Image.open(mask_path).convert("L")

        img = np.asarray(img)
        mask = np.asarray(mask)
        if self.mask_divide:
            mask = mask // self.divide_value
        # sample = {"image": img, "label": mask}
        # if None not in (self.ops_weak, self.ops_strong):
        #         sample = self.transform(sample, self.ops_weak, self.ops_strong)
        # else:
        #         sample = self.transform(sample)
        transform = Compose(
            [
                # ColorJitter(),
                # VerticalFlip(),
                # HorizontalFlip(),
                Resize(self.img_size, self.img_size),
                Normalize(mean=self.pixel_mean, std=self.pixel_std)
            ]
        )

        aug_data = transform(image=img,mask=mask)
        x = aug_data["image"]
        target = aug_data["mask"]
        if img.ndim == 3:
            x = np.transpose(x, axes=[2, 0, 1])
        elif img.ndim == 2:
            x = np.expand_dims(x, axis=0)
        sample = {"image": torch.from_numpy(x), "label": torch.from_numpy(target)}
        # sample = {"image": x, "label": target}
        return sample
def inference(args, multimask_output, db_config, model, test_save_path=None):
    # with open(args.root_path + '/test.list', 'r') as f:
    #     image_list = f.readlines()
    # image_list = sorted([item.replace('\n', '').split(".")[0]
    #                      for item in image_list])
    
    metric_list = 0.0
     
    first_total = 0.0
    second_total = 0.0
    third_total = 0.0
    # first_list = np.zeros([len(image_list), 4])
    # second_list = np.zeros([len(image_list), 4])
    # third_list = np.zeros([len(image_list), 4])
    count = 0

    # img_path = r"D:\2024\ssr\DATA\CHASE\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\CHASE\test\mask"
    # img_path = r"D:\2024\ssr\DATA\FIVES\test\Original"
    # mask_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # prompt_path = r"D:\2024\ssr\DATA\FIVES\test\Ground truth"
    # img_path = r"D:\2024\ssr\DATA\STARE\Images"
    # mask_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # prompt_path = r"D:\2024\ssr\DATA\STARE\Masks"
    # img_path = r"D:\2024\ssr\DATA\CXR\test\image"
    # mask_path = r"D:\2024\ssr\DATA\CXR\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\CXR\test\mask"
    # img_path =r"D:\2024\ssr\DATA\BUSI\test\image"
    # mask_path =r"D:\2024\ssr\DATA\BUSI\test\mask"
    # prompt_path=r"D:\2024\ssr\DATA\BUSI\test\mask"
    # img_path = r"D:\2024\ssr\DATA\MoNuseg\test\image"
    # mask_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # prompt_path = r"D:\2024\ssr\DATA\MoNuseg\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\image"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\CVC-ClinicDB\test\mask"
    # img_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\images"
    # mask_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    # prompt_path = r"D:\2024\ssr\LearnablePromptSAM-main\DRIVE\test\1st_manual"
    img_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\image"
    mask_path=r"D:\2024\ssr\DATA\Kavsir-SEG\test\mask"
    basename = os.path.basename(img_path)
    _, ext = os.path.splitext(basename)
    if ext == "":
        regex = re.compile(".*\.(jpe?g|png|gif|tif|bmp)$", re.IGNORECASE)
        img_paths = [file for file in glob.glob(os.path.join(img_path, "*.*")) if regex.match(file)]
        print("train with {} imgs".format(len(img_paths)))
        mask_paths = [os.path.join(mask_path, os.path.splitext(os.path.basename(file))[0] + '.png') for file
                      in
                      img_paths]

    # image = h5f['image'][:]
    # label = h5f['label'][:]
    dataset = testDataset(img_paths, mask_paths=mask_paths, mask_divide=True, img_size=1024)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=1)
    metric = Metric(num_classes=2)
    test_save_path=r"D:\2024\ssr\CPC-SAM-main\Kavsir-SEG\CPC-SAM299"
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    for i, sample in enumerate(dataloader):
        test_single_image(sample, model, classes=args.num_classes, multimask_output=multimask_output,i=i,metric=metric,
                                      patch_size=[args.img_size, args.img_size], input_size=[args.input_size, args.input_size],
                                      test_save_path=test_save_path)

    iou = np.nanmean(metric.evaluate()["iou"][1:].numpy())
    print("iou:{}".format(iou.item()))
    dice = np.nanmean(metric.evaluate()["dice"][1:].numpy())
    print("dice:{}".format(dice.item()))
    se = np.nanmean(metric.evaluate()["se"][1:].numpy())
    print("se:{}".format(se.item()))
    sp = np.nanmean(metric.evaluate()["specifity"][1:].numpy())
    print("specifity:{}".format(sp.item()))
    acc = np.nanmean(metric.evaluate()["acc"][1:].numpy())
    print("acc:{}".format(acc.item()))
    # for case in tqdm(image_list):
    #     h5f = h5py.File(args.root_path + "/data/{}.h5".format(case), 'r')
    #     image = h5f['image'][:]
    #     label = h5f['label'][:]
    #
    #     metric_i = test_single_volume_mean(image, label, model, classes=args.num_classes, multimask_output=multimask_output,
    #                                   patch_size=[args.img_size, args.img_size], input_size=[args.input_size, args.input_size],
    #                                   test_save_path=test_save_path, case= case,z_spacing=db_config['z_spacing'])
    #     first_metric = metric_i[0]
    #     second_metric = metric_i[1]
    #     third_metric = metric_i[2]
    #
    #     first_total += np.asarray(first_metric)
    #     second_total += np.asarray(second_metric)
    #     third_total += np.asarray(third_metric)
    #
    #     # save
    #     first_list[count, 0]=first_metric[0]
    #     first_list[count, 1]=first_metric[1]
    #     first_list[count, 2]=first_metric[2]
    #     first_list[count, 3]=first_metric[3]
    #
    #     second_list[count, 0]=second_metric[0]
    #     second_list[count, 1]=second_metric[1]
    #     second_list[count, 2]=second_metric[2]
    #     second_list[count, 3]=second_metric[3]
    #
    #     third_list[count, 0]=third_metric[0]
    #     third_list[count, 1]=third_metric[1]
    #     third_list[count, 2]=third_metric[2]
    #     third_list[count, 3]=third_metric[3]
    #
    #     count += 1
    #
    # avg_metric1 = np.nanmean(first_list, axis=0)
    # avg_metric2 = np.nanmean(second_list, axis=0)
    # avg_metric3 = np.nanmean(third_list, axis=0)
    #
    # # save:
    # write_csv = "xxx/output/save_excel/" + args.exp + "_test_mean.csv"
    # save = pd.DataFrame({'RV-dice':first_list[:,0], 'RV-hd95':first_list[:,1], 'RV-asd':first_list[:,2], 'RV-jc':first_list[:,3], 'Myo-dice':second_list[:,0], 'Myo-hd95':second_list[:,1], 'Myo-asd':second_list[:,2],
    # 'Myo-jc':second_list[:,3], 'LV-dice':third_list[:,0], 'LV-hd95':third_list[:,1], 'LV-asd':third_list[:,2], 'LV-jc':third_list[:,3]})
    # save.to_csv(write_csv, index=False, sep=',')
    #
    # print(avg_metric1, avg_metric2, avg_metric3)
    # print((avg_metric1+avg_metric2+avg_metric3)/3)
    # logging.info("Testing Finished!")
    # return 1
    #

def config_to_dict(config):
    items_dict = {}
    with open(config, 'r') as f:
        items = f.readlines()
    for i in range(len(items)):
        key, value = items[i].strip().split(': ')
        items_dict[key] = value
    return items_dict


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root_path', type=str,
                    default='xxx/data/ACDC', help='Name of Experiment')
    parser.add_argument('--config', type=str, default=None, help='The config file provided by the trained model')
    parser.add_argument('--dataset', type=str, default='ACDC', help='Experiment name')
    parser.add_argument('--num_classes', type=int, default=1)
    parser.add_argument('--output_dir', type=str, default='xxx/')
    parser.add_argument('--img_size', type=int, default=1024, help='Input image size of the network')
    parser.add_argument('--input_size', type=int, default=1024, help='The input size for training SAM model')
    parser.add_argument('--seed', type=int,
                        default=1337, help='random seed')
    parser.add_argument('--is_savenii', action='store_true', default=False,help='Whether to save results during inference')
    parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
    parser.add_argument('--ckpt', type=str, default='xxx/sam_vit_b_01ec64.pth',
                        help='Pretrained checkpoint')
    
    parser.add_argument('--lora_ckpt', type=str, default=r'D:\2024\ssr\CPC-SAM-main\xxx\output\sam\results_ssl\Kavsir-SEG\epoch_199.pth', help='The checkpoint from LoRA')
    parser.add_argument('--vit_name', type=str, default='vit_b_dualmask_same_prompt_class_random_large', help='Select one vit model')
    parser.add_argument('--rank', type=int, default=4, help='Rank for LoRA adaptation')
    parser.add_argument('--module', type=str, default='sam_lora_image_encoder_prompt')
    parser.add_argument('--exp', type=str, default='test_name')
    parser.add_argument('--promptmode', type=str, default='point',help='prompt')

    args = parser.parse_args()

    if args.config is not None:
        # overwtite default configurations with config file\
        config_dict = config_to_dict(args.config)
        for key in config_dict:
            setattr(args, key, config_dict[key])

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    dataset_name = args.dataset
    dataset_config = {
        'ACDC': {
            'Dataset': ACDC_dataset,
            'num_classes': args.num_classes,
            'z_spacing': 1
        }
    }
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
    
    
    # register model
    sam, img_embedding_size = sam_model_registry[args.vit_name](image_size=args.img_size,
                                                                    num_classes=args.num_classes,
                                                                    checkpoint=args.ckpt, pixel_mean=[0, 0, 0],
                                                                    pixel_std=[1, 1, 1])
    pkg = import_module(args.module)
    net = pkg.LoRA_Sam(sam, args.rank).cuda()

    assert args.lora_ckpt is not None
    net.load_lora_parameters(args.lora_ckpt)

    if args.num_classes > 1:
        multimask_output = True
    else:
        multimask_output = False

    # initialize log
    log_folder = os.path.join(args.output_dir, 'test_log')
    os.makedirs(log_folder, exist_ok=True)
    logging.basicConfig(filename=log_folder + '/' + 'log.txt', level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))

    if args.is_savenii:
        test_save_path = os.path.join(args.output_dir, 'predictions')
        os.makedirs(test_save_path, exist_ok=True)
    else:
        test_save_path = None
    labeled_num=10
    test_save_path = "./resault/BUSI_{}_labeled/predictions/".format(
       labeled_num)

    os.makedirs(test_save_path,exist_ok=True)
    inference(args, multimask_output, dataset_config[dataset_name], net, test_save_path=test_save_path)

