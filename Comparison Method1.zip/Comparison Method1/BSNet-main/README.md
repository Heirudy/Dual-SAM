# BSNet

 This repository contains the implementation of our paper "Bilateral Supervision Network for Semi-supervised Medical Image Segmentation"
