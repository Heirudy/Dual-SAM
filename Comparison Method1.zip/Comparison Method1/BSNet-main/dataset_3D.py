import os
import cv2
import h5py
import torch
import random
import numpy as np
from glob import glob

from skimage.measure import label
from torch.utils.data import Dataset
from einops import repeat
from scipy.ndimage.interpolation import zoom
from torchvision import transforms
import itertools
from scipy import ndimage
from torch.utils.data.sampler import Sampler
# from code import augmentations
# from augmentations.ctaugment import OPS

import matplotlib.pyplot as plt
from PIL import Image
from tqdm import tqdm

# https://raw.githubusercontent.com/google-research/fixmatch/master/libml/ctaugment.py
#
# Copyright 2019 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Control Theory based self-augmentation, modified from https://github.com/vfdev-5/FixMatch-pytorch"""
import random
import torch
from collections import namedtuple

import numpy as np
from scipy.ndimage.interpolation import zoom
from PIL import Image, ImageOps, ImageEnhance, ImageFilter
from torch.nn import functional as F

OPS = {}
OP = namedtuple("OP", ("f", "bins"))
Sample = namedtuple("Sample", ("train", "probe"))


def register(*bins):
    def wrap(f):
        OPS[f.__name__] = OP(f, bins)
        return f

    return wrap


class CTAugment(object):
    def __init__(self, depth=2, th=0.85, decay=0.99):
        self.decay = decay
        self.depth = depth
        self.th = th
        self.rates = {}
        for k, op in OPS.items():
            self.rates[k] = tuple([np.ones(x, "f") for x in op.bins])

    def rate_to_p(self, rate):
        p = rate + (1 - self.decay)  # Avoid to have all zero.
        p = p / p.max()
        p[p < self.th] = 0
        return p

    def policy(self, probe, weak):
        num_strong_ops = 11
        kl_weak = list(OPS.keys())[num_strong_ops:]
        kl_strong = list(OPS.keys())[:num_strong_ops]

        if weak:
            kl = kl_weak
        else:
            kl = kl_strong

        v = []
        if probe:
            for _ in range(self.depth):
                k = random.choice(kl)
                bins = self.rates[k]
                rnd = np.random.uniform(0, 1, len(bins))
                v.append(OP(k, rnd.tolist()))
            return v
        for _ in range(self.depth):
            vt = []
            k = random.choice(kl)
            bins = self.rates[k]
            rnd = np.random.uniform(0, 1, len(bins))
            for r, bin in zip(rnd, bins):
                p = self.rate_to_p(bin)
                value = np.random.choice(p.shape[0], p=p / p.sum())
                vt.append((value + r) / p.shape[0])
            v.append(OP(k, vt))
        return v

    def update_rates(self, policy, proximity):
        for k, bins in policy:
            for p, rate in zip(bins, self.rates[k]):
                p = int(p * len(rate) * 0.999)
                rate[p] = rate[p] * self.decay + proximity * (1 - self.decay)
            print(f"\t {k} weights updated")

    def stats(self):
        return "\n".join(
            "%-16s    %s"
            % (
                k,
                " / ".join(
                    " ".join("%.2f" % x for x in self.rate_to_p(rate))
                    for rate in self.rates[k]
                ),
            )
            for k in sorted(OPS.keys())
        )


def _enhance(x, op, level):
    return op(x).enhance(0.1 + 1.9 * level)


def _imageop(x, op, level):
    return Image.blend(x, op(x), level)


def _filter(x, op, level):
    return Image.blend(x, x.filter(op), level)


@register(17)
def autocontrast(x, level):
    return _imageop(x, ImageOps.autocontrast, level)


@register(17)
def brightness(x, brightness):
    return _enhance(x, ImageEnhance.Brightness, brightness)


@register(17)
def color(x, color):
    return _enhance(x, ImageEnhance.Color, color)


@register(17)
def contrast(x, contrast):
    return _enhance(x, ImageEnhance.Contrast, contrast)


@register(17)
def equalize(x, level):
    return _imageop(x, ImageOps.equalize, level)


@register(17)
def invert(x, level):
    return _imageop(x, ImageOps.invert, level)


@register(8)
def posterize(x, level):
    level = 1 + int(level * 7.999)
    return ImageOps.posterize(x, level)


@register(17)
def solarize(x, th):
    th = int(th * 255.999)
    return ImageOps.solarize(x, th)


@register(17)
def smooth(x, level):
    return _filter(x, ImageFilter.SMOOTH, level)


@register(17)
def blur(x, level):
    return _filter(x, ImageFilter.BLUR, level)


@register(17)
def sharpness(x, sharpness):
    return _enhance(x, ImageEnhance.Sharpness, sharpness)


# weak after here


@register(17)
def cutout(x, level):
    """Apply cutout to pil_img at the specified level."""
    size = 1 + int(level * min(x.size) * 0.499)
    img_height, img_width = x.size
    height_loc = np.random.randint(low=img_height // 2, high=img_height)
    width_loc = np.random.randint(low=img_height // 2, high=img_width)
    upper_coord = (max(0, height_loc - size // 2), max(0, width_loc - size // 2))
    lower_coord = (
        min(img_height, height_loc + size // 2),
        min(img_width, width_loc + size // 2),
    )
    pixels = x.load()  # create the pixel map
    for i in range(upper_coord[0], lower_coord[0]):  # for every col:
        for j in range(upper_coord[1], lower_coord[1]):  # For every row
            x.putpixel((i, j), 0)  # set the color accordingly
    return x


@register()
def identity(x):
    return x


@register(17, 6)
def rescale(x, scale, method):
    s = x.size
    scale *= 0.25
    crop = (scale * s[0], scale * s[1], s[0] * (1 - scale), s[1] * (1 - scale))
    methods = (
        Image.ANTIALIAS,
        Image.BICUBIC,
        Image.BILINEAR,
        Image.BOX,
        Image.HAMMING,
        Image.NEAREST,
    )
    method = methods[int(method * 5.99)]
    return x.crop(crop).resize(x.size, method)


@register(17)
def rotate(x, angle):
    angle = int(np.round((2 * angle - 1) * 45))
    return x.rotate(angle)


@register(17)
def shear_x(x, shear):
    shear = (2 * shear - 1) * 0.3
    return x.transform(x.size, Image.AFFINE, (1, shear, 0, 0, 1, 0))


@register(17)
def shear_y(x, shear):
    shear = (2 * shear - 1) * 0.3
    return x.transform(x.size, Image.AFFINE, (1, 0, 0, shear, 1, 0))


@register(17)
def translate_x(x, delta):
    delta = (2 * delta - 1) * 0.3
    return x.transform(x.size, Image.AFFINE, (1, 0, delta, 0, 1, 0))


@register(17)
def translate_y(x, delta):
    delta = (2 * delta - 1) * 0.3
    return x.transform(x.size, Image.AFFINE, (1, 0, 0, 0, 1, delta))




class BaseDataSets(Dataset):
    def __init__(
            self,
            base_dir=None,
            split="train",
            num=None,
            transform=None,
    ):
        self._base_dir = base_dir
        self.sample_list = []
        self.split = split
        self.transform = transform

        if self.split == "train":
            with open(self._base_dir + "/train_slices.list", "r") as f1:
                self.sample_list = f1.readlines()
            self.sample_list = [item.replace("\n", "") for item in self.sample_list]

        elif self.split == "val":
            with open(self._base_dir + "/val.list", "r") as f:
                self.sample_list = f.readlines()
            self.sample_list = [item.replace("\n", "") for item in self.sample_list]
        if num is not None and self.split == "train":
            self.sample_list = self.sample_list[:num]
        print("total {} samples".format(len(self.sample_list)))

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        case = self.sample_list[idx]
        # print('case: ', case)
        if self.split == "train":
            h5f = h5py.File(self._base_dir + "/data/slices/{}.h5".format(case), "r")
        else:
            h5f = h5py.File(self._base_dir + "/data/{}.h5".format(case), "r")

        image = h5f["image"][:]
        label = h5f["label"][:]
        sample = {"image": image, "label": label}
        # print('image.min(): ', image.min())
        # print('image.max(): ', image.max())
        if self.split == "train":
            sample = self.transform(sample)

        sample['case_name'] = self.sample_list[idx].strip('\n')
        return sample

def get_bbox(mask, bbox_shift=5):
    y_indices, x_indices = np.where(mask > 0)
    x_min, x_max = np.min(x_indices), np.max(x_indices)
    y_min, y_max = np.min(y_indices), np.max(y_indices)
    # add perturbation to bounding box coordinates
    H, W = mask.shape
    x_min = max(0, x_min - bbox_shift)
    x_max = min(W, x_max + bbox_shift)
    y_min = max(0, y_min - bbox_shift)
    y_max = min(H, y_max + bbox_shift)
    bboxes = np.array([x_min, y_min, x_max, y_max])
    return bboxes


def show_box(box, ax):
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(plt.Rectangle((x0, y0), w, h, edgecolor='green', facecolor=(0, 0, 0, 0), lw=2))


def show_mask(mask, ax, random_color=False):
    # 确定类别数量
    num_classes = mask.max() + 1

    if random_color:
        # 为每个类别生成一个随机颜色
        colors = np.random.random((num_classes, 3))
        # 将背景类别设置为黑色且不透明
        colors[0, :] = 0  # 背景类别为0，设置为黑色
    else:
        # 定义一个颜色列表，为每个类别分配一个颜色
        colors = np.array([
            [30 / 255, 144 / 255, 255 / 255],  # 类别1
            [255 / 255, 215 / 255, 0 / 255],  # 类别2
            [255 / 255, 0 / 255, 0 / 255],  # 类别3
            [0 / 255, 0 / 255, 0 / 255]  # 背景类别，设置为黑色
        ])

    # 创建一个全黑的图像作为基础
    h, w = mask.shape
    mask_image = np.zeros((h, w, 3))

    # 为每个类别着色
    for i in range(num_classes):
        mask_image[mask == i] = colors[i]

    # 显示图像，设置透明度
    ax.imshow(mask_image, alpha=0.6)


# def show_mask(mask, ax, random_color=False):
#     if random_color:
#         color = np.concatenate([np.random.random(3), np.array([0.6])], axis=0)
#     else:
#         color = np.array([30 / 255, 144 / 255, 255 / 255, 0.6])
#     h, w = mask.shape[-2:]
#     mask_image = mask.reshape(h, w, 1) * color.reshape(1, 1, -1)
#     ax.imshow(mask_image)


def show_points(coords, labels, ax, marker_size=375):
    # pos_points = coords[labels == 1 |labels == 2 | labels == 3 | labels==4]
    pos_points = coords[(labels == 1) | (labels == 2) | (labels == 3) | (labels == 4)]
    neg_points = coords[labels == 0]
    ax.scatter(pos_points[:, 0], pos_points[:, 1], color='green', marker='*', s=marker_size, edgecolor='white',
               linewidth=1.25)
    ax.scatter(neg_points[:, 0], neg_points[:, 1], color='red', marker='*', s=marker_size, edgecolor='white',
               linewidth=1.25)


def get_bboxes(image, mask):
    # y_indices, x_indices = np.where(mask > 0)
    # if len(x_indices)==0 or len(y_indices) == 0:
    #     return None
    # x_min, x_max = np.min(x_indices), np.max(x_indices)
    # y_min, y_max = np.min(y_indices), np.max(y_indices)
    B, H, W = mask.shape
    # x_min = max(0, x_min - bbox_shift)
    # x_max = min(W, x_max + bbox_shift)
    # y_min = max(0, y_min - bbox_shift)
    # y_max = min(H, y_max + bbox_shift)
    # bboxes = np.array([x_min, y_min, x_max, y_max])
    # return bboxes

    # print(f'label ids: {label_ids}')

    # seg_data = np.zeros_like(image, dtype=np.uint8)
    mask=mask.detach().cpu().numpy()
    label_ids = np.unique(mask)[1:]
    for label_id in label_ids:
        marker_data_id = (mask == label_id).astype(np.uint8)
        marker_zids, _, _ = np.where(marker_data_id > 0)
        marker_zids = np.sort(np.unique(marker_zids))

        bbox_dict = {}  # key: z_index, value: bbox
        for z in marker_zids:
            # get bbox for each slice
            z_box = get_bbox(marker_data_id[z, :, :], bbox_shift=5)
            bbox_dict[z] = z_box
        # find largest bbox in bbox_dict
        bbox_areas = [np.prod(bbox_dict[z][2:] - bbox_dict[z][:2]) for z in bbox_dict.keys()]
        z_middle = list(bbox_dict.keys())[np.argmax(bbox_areas)]  # middle slice
        z_min = min(bbox_dict.keys())
        z_max = max(bbox_dict.keys())
        z_middle_bbox = bbox_dict[z_middle]
        z_max_bbox = bbox_dict[z_max]
        # bbox_dict[z] / np.array([W, H, W, H]) * 512

    return z_max_bbox
        # sanity check
        # img_roi = image_data_pre[z_middle, z_middle_bbox[1]:z_middle_bbox[3], z_middle_bbox[0]:z_middle_bbox[2]]
        # io.imsave(name.split('.nii.gz')[0] + '_roi.png', img_roi)

        # infer from middle slice to the z_max

        # for z in tqdm(range(z_middle, z_max + 1)):  # include z_max
        #     img_2d = image[z, :, :]
        #     if len(img_2d.shape) == 2:
        #         img_3c = np.repeat(img_2d[:, :, None], 3, axis=-1)
        #     else:
        #         img_3c = img_2d
        #     H, W, _ = img_3c.shape
        #     # img_1024_tensor = torch.tensor(img_3c).float().permute(2, 0, 1).unsqueeze(0).to(device)
        #     # get the image embedding
        #     # with torch.no_grad():
        #     #     image_embedding = medsam_model.image_encoder(img_1024_tensor)  # (1, 256, 64, 64)
        #     if z in bbox_dict.keys():
        #         box_1024 = bbox_dict[z] / np.array([W, H, W, H]) * 512
        #     else:
        #         pre_seg = seg_data[z - 1, :, :]  # use the previous slice
        #         if np.max(pre_seg) > 0:
        #             pre_seg1024 = cv2.resize(pre_seg, (1024, 1024), interpolation=cv2.INTER_NEAREST)
        #             box_1024 = get_bbox(pre_seg1024)
        #         else:
        #             # find the closest z index in bbox_dict
        #             z_diff = [abs(z - z_id) for z_id in bbox_dict.keys()]
        #             z_closest = list(bbox_dict.keys())[np.argmin(z_diff)]
        #             box_1024 = bbox_dict[z_closest] / np.array([W, H, W, H]) * 1024
        #     bbox_dict[z] = box_1024 / 512 * np.array([W, H, W, H])
        #
        # # infer from middle slice to the z_min
        # # print('infer', name, 'from middle slice to the z_min')
        # for z in tqdm(range(z_middle - 1, z_min - 1, -1)):
        #     img_2d = image[z, :, :]
        #     if len(img_2d.shape) == 2:
        #         img_3c = np.repeat(img_2d[:, :, None], 3, axis=-1)
        #     else:
        #         img_3c = img_2d
        #     H, W, _ = img_3c.shape
        #     img_1024_tensor = torch.tensor(img_3c).float().permute(2, 0, 1).unsqueeze(0).to(device)
        #     # get the image embedding
        #     # with torch.no_grad():
        #     #     image_embedding = medsam_model.image_encoder(img_1024_tensor)  # (1, 256, 64, 64)
        #
        #     if z in bbox_dict.keys():
        #         box_1024 = bbox_dict[z] / np.array([W, H, W, H]) * 1024
        #     else:
        #         pre_seg = seg_data[z + 1, :, :]
        #         if np.max(pre_seg) > 0:
        #             pre_seg1024 = cv2.resize(pre_seg, (1024, 1024), interpolation=cv2.INTER_NEAREST)
        #             box_1024 = get_bbox(pre_seg1024.astype(np.uint8))
        #         else:
        #             # find the closest z index in bbox_dict
        #             z_diff = [abs(z - z_id) for z_id in bbox_dict.keys()]
        #             z_closest = list(bbox_dict.keys())[np.argmin(z_diff)]
        #             box_1024 = bbox_dict[z_closest] / np.array([W, H, W, H]) * 1024
        #     bbox_dict[z] = box_1024 / 1024 * np.array([W, H, W, H])
        #     img_2d_seg = medsam_inference(medsam_model, image_embedding, box_1024[None, :], H, W)
        #     seg_data[z, img_2d_seg > 0] = 1

def random_rot_flip(image, label=None):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    if label is not None:
        label = np.rot90(label, k)
        label = np.flip(label, axis=axis).copy()
        return image, label
    else:
        return image


def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label


def color_jitter(image):
    if not torch.is_tensor(image):
        np_to_tensor = transforms.ToTensor()
        image = np_to_tensor(image)

    # s is the strength of color distortion.
    s = 1.0
    jitter = transforms.ColorJitter(0.8 * s, 0.8 * s, 0.8 * s, 0.2 * s)
    return jitter(image)

def cta_apply(self, pil_img, ops):
    if ops is None:
        return pil_img
    for op, args in ops:
        pil_img = OPS[op].f(pil_img, *args)
    return pil_img

class CTATransform(object):
    def __init__(self, output_size, cta):
        self.output_size = output_size
        self.cta = cta

    def __call__(self, sample, ops_weak, ops_strong):
        image, label = sample["image"], sample["label"]
        image = self.resize(image)
        label = self.resize(label)
        to_tensor = transforms.ToTensor()

        # fix dimensions
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.uint8))

        # apply augmentations
        image_weak = cta_apply(transforms.ToPILImage()(image), ops_weak)
        image_strong = cta_apply(image_weak, ops_strong)
        label_aug = cta_apply(transforms.ToPILImage()(label), ops_weak)
        label_aug = to_tensor(label_aug).squeeze(0)
        label_aug = torch.round(255 * label_aug).int()

        sample = {
            "image_weak": to_tensor(image_weak),
            "image_strong": to_tensor(image_strong),
            "label_aug": label_aug,
        }
        return sample

    # def cta_apply(self, pil_img, ops):
    #     if ops is None:
    #         return pil_img
    #     for op, args in ops:
    #         pil_img = OPS[op].f(pil_img, *args)
    #     return pil_img

    def resize(self, image):
        x, y = image.shape
        return zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)


# class RandomGenerator(object):
#     def __init__(self, output_size):
#         self.output_size = output_size
#
#     def __call__(self, sample):
#         image, label = sample["image"], sample["label"]
#         # ind = random.randrange(0, img.shape[0])
#         # image = img[ind, ...]
#         # label = lab[ind, ...]
#         if random.random() > 0.5:
#             image, label = random_rot_flip(image, label)
#         elif random.random() > 0.5:
#             image, label = random_rotate(image, label)
#         x, y = image.shape
#         image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)
#         label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
#         image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
#         label = torch.from_numpy(label.astype(np.uint8))
#         sample = {"image": image, "label": label}
#         return sample


class WeakStrongAugment(object):
    """returns weakly and strongly augmented images

    Args:
        object (tuple): output size of network
    """

    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample["image"], sample["label"]
        image = self.resize(image)
        label = self.resize(label)
        # weak augmentation is rotation / flip
        image_weak, label = random_rot_flip(image, label)
        # strong augmentation is color jitter
        image_strong = color_jitter(image_weak).type("torch.FloatTensor")
        # fix dimensions
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        image_weak = torch.from_numpy(image_weak.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.uint8))

        sample = {
            "image": image,
            "image_weak": image_weak,
            "image_strong": image_strong,
            "label_aug": label,
        }
        return sample

    def resize(self, image):
        x, y = image.shape
        return zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=0)


class TwoStreamBatchSampler(Sampler):
    """Iterate two sets of indices

    An 'epoch' is one iteration through the primary indices.
    During the epoch, the secondary indices are iterated through
    as many times as needed.
    """

    def __init__(self, primary_indices, secondary_indices, batch_size, secondary_batch_size):
        self.primary_indices = primary_indices
        self.secondary_indices = secondary_indices
        self.secondary_batch_size = secondary_batch_size
        self.primary_batch_size = batch_size - secondary_batch_size

        assert len(self.primary_indices) >= self.primary_batch_size > 0
        assert len(self.secondary_indices) >= self.secondary_batch_size > 0

    def __iter__(self):
        primary_iter = iterate_once(self.primary_indices)
        secondary_iter = iterate_eternally(self.secondary_indices)
        return (
            primary_batch + secondary_batch
            for (primary_batch, secondary_batch) in zip(
                grouper(primary_iter, self.primary_batch_size),
                grouper(secondary_iter, self.secondary_batch_size),
            )
        )

    def __len__(self):
        return len(self.primary_indices) // self.primary_batch_size
class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size


    def __call__(self, sample):
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)  # why not 3?
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        image = repeat(image, 'c h w -> (repeat c) h w', repeat=3)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample

def iterate_once(iterable):
    return np.random.permutation(iterable)


def iterate_eternally(indices):
    def infinite_shuffles():
        while True:
            yield np.random.permutation(indices)

    return itertools.chain.from_iterable(infinite_shuffles())


def grouper(iterable, n):
    "Collect data into fixed-length chunks or blocks"
    # grouper('ABCDEFG', 3) --> ABC DEF"
    args = [iter(iterable)] * n
    return zip(*args)


def prompt_generate_random_fast(coarse_mask, img_size, israndom=False):
    b, h, w = coarse_mask.shape
    num_class=4


    # coarse_mask_np = torch.argmax(coarse_mask, dim=1)
    coarse_mask_np = F.interpolate(coarse_mask.unsqueeze(1).float(), (img_size, img_size), mode="nearest").squeeze(1)
    coarse_mask_np = coarse_mask_np.detach().cpu().numpy()

    points_prompt = np.zeros((b, num_class, 2))
    points_label = np.zeros((b, num_class))
    points_prompt_random = np.zeros((b, num_class, 2))

    for idx in range(b):
        for cls in range(num_class):
            mask_cls = (coarse_mask_np[idx] == cls).astype(np.uint8)
            if mask_cls.max() > 0:
                label_msk, region_ids = label(mask_cls, connectivity=2, return_num=True)
                ratio_list, regionid_list = [], []

                for region_id in range(1, region_ids + 1):
                    binary_msk = np.where(label_msk == region_id, 1, 0)
                    r = np.sum(binary_msk) / np.sum(mask_cls)
                    ratio_list.append(r)
                    regionid_list.append(region_id)

                ratio_list, regionid_list = zip(*sorted(zip(ratio_list, regionid_list)))
                regionid_list = regionid_list[::-1]

                binary_msk = np.where(label_msk == regionid_list[0], 1, 0)

                if israndom:
                    cY_r, cX_r = np.where(binary_msk == 1)
                    random_idx = np.random.randint(0, len(cX_r))
                    points_prompt_random[idx, cls, 0], points_prompt_random[idx, cls, 1] = int(cX_r[random_idx]), int(
                        cY_r[random_idx])

                padded_mask = np.uint8(np.pad(binary_msk, ((1, 1), (1, 1)), 'constant'))
                dist_img = cv2.distanceTransform(padded_mask, distanceType=cv2.DIST_L2, maskSize=5).astype(np.float32)[
                           1:-1, 1:-1]
                cY, cX = np.where(dist_img == dist_img.max())
                random_idx = np.random.randint(0, len(cX))
                points_prompt[idx, cls, 0], points_prompt[idx, cls, 1] = int(cX[random_idx]), int(cY[random_idx])

                if cls > 0:
                    points_label[idx, cls] = cls

            else:
                points_prompt[idx, cls, 0], points_prompt[idx, cls, 1] = points_prompt[idx, 0, 0], points_prompt[
                    idx, 0, 1]
                points_prompt_random[idx, cls, 0], points_prompt_random[idx, cls, 1] = points_prompt[idx, 0, 0], \
                points_prompt[idx, 0, 1]
                points_label[idx, cls] = 0

    points_prompt = torch.tensor(points_prompt).to(coarse_mask.device)
    points_label = torch.tensor(points_label).to(coarse_mask.device)
    points_prompt = (points_prompt, points_label)


    points_prompt_random = torch.tensor(points_prompt_random).to(coarse_mask.device)
    points_prompt_random = (points_prompt_random, points_label)



    return  points_prompt







