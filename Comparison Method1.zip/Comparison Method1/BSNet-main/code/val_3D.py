
import numpy as np
import torch
from medpy import metric
from scipy.ndimage import zoom
from einops import repeat
import torch.nn.functional as F




def custom_mask(outputs1, outputs2, threshold=0.9,kernel_size=11):
    # 计算整个输出的差异
    diff = torch.abs(outputs1 - outputs2)
    # 创建一个阈值掩码，其中差异小于阈值的位置为True
    threshold_mask = diff < threshold

    # 计算outputs1和outputs2的平均值
    average = (outputs1 + outputs2) / 2

    # 首先，对小于阈值的部分填充平均值，否则填充0
    new_vector = torch.where(threshold_mask, average, torch.zeros_like(outputs1))

    # 计算反向掩码
    inverse_threshold_mask = ~threshold_mask

    # 对整个new_vector进行均值滤波，这里假设使用简单的均值滤波
    # 需要一个窗口大小，这里假设为3x3，并且假设outputs1是4D张量（批次，通道，高度，宽度）

    # 定义均值滤波核
    kernel = torch.ones(1, 1, kernel_size, kernel_size) / (kernel_size ** 2)
    kernel = kernel.cuda()
    # 为了保持原始尺寸，需要相应的填充
    padding = (kernel_size - 1) // 2

    # 扩展卷积核的维度以适应 F.conv2d
    kernel = kernel.expand( new_vector.size(1), -1, -1, -1)  # 适配输入张量的通道数

    # 执行卷积操作
    aver_vector = F.conv2d( new_vector, kernel, padding=padding, groups= new_vector.size(1))

    # 使用inverse_threshold_mask过滤aver_vector
    filtered_aver_vector = torch.where(inverse_threshold_mask, aver_vector, torch.zeros_like(new_vector))

    # 将过滤后的aver_vector与new_vector相加
    final_vector = new_vector + filtered_aver_vector
    return final_vector
def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    if pred.sum() > 0:
        dice = metric.binary.dc(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
        return dice, hd95
    else:
        return 0, 0
    # pred[pred > 0] = 1
    # gt[gt > 0] = 1
    # dice = metric.binary.dc(pred, gt)
    # if pred.sum() != 0:
    #     asd = metric.binary.asd(pred, gt)
    #     hd95 = metric.binary.hd95(pred, gt)
    # else:
    #     print('bad')
    #     asd = -1
    #     hd95 = -1
    # # jc = metric.binary.jc(pred, gt)
    # return dice, hd95


def test_single_volume(image, label,model, classes,  patch_size=[512, 512]):
    image, label = image.squeeze(0).cpu().detach(
    ).numpy(), label.squeeze(0).cpu().detach().numpy()
    prediction1 = np.zeros_like(label)
    for ind in range(image.shape[0]):

        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        inputs = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)


        with torch.no_grad():
            outputs = model(inputs)
            outputs_soft = torch.softmax(outputs, dim=1)
            out1 = torch.argmax(outputs_soft, dim=1).squeeze(0)
            out1 = out1.cpu().detach().numpy()

            out_h, out_w = out1.shape
            if x != out_h or y != out_w:
                pred1 = zoom(out1, (x / out_h, y / out_w), order=0)

            else:
                pred1 = out1

            prediction1[ind] = pred1

    metric_list1 = []

    for i in range(1, classes):
        metric_list1.append(calculate_metric_percase(
            prediction1 == i, label == i))

    return metric_list1


def test_single_image(image, label, net, classes, multimask_output=True, patch_size=[512, 512]):
    image, label = image.squeeze(0).cpu().detach(
    ).numpy(), label.squeeze(0).cpu().detach().numpy()
    prediction = np.zeros_like(label)

    # for ind in range(image.shape[0]):

    slice = image
    x, y = slice.shape[0], slice.shape[1]
    slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)
    input = torch.from_numpy(slice).unsqueeze(
        0).unsqueeze(0).float().cuda()
    inputs = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)

    net.eval()

    with torch.no_grad():
        outputs = net(inputs, multimask_output, patch_size[0])
        output_masks = outputs['masks']
        out = torch.argmax(torch.softmax(output_masks, dim=1), dim=1).squeeze(0)
        out = out.cpu().detach().numpy()
        out_h, out_w = out.shape
        if x != out_h or y != out_w:
            pred = zoom(out, (x / out_h, y / out_w), order=0)
        else:
            pred = out
        prediction = pred

    metric_list = []
    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(
            prediction == i, label == i))
    return metric_list


def test_single_volume_prompt(image, label, net, classes, promptidx, promptmode, multimask_output=True,
                              patch_size=[512, 512]):
    image, label = image.squeeze(0).cpu().detach(
    ).numpy(), label.squeeze(0).cpu().detach().numpy()
    prediction = np.zeros_like(label)

    for ind in range(image.shape[0]):

        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        inputs = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)

        net.eval()

        with torch.no_grad():
            outputs = net(inputs, multimask_output, patch_size[0], promptidx, promptmode)
            output_masks = outputs['masks']
            out = torch.argmax(torch.softmax(output_masks, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            out_h, out_w = out.shape
            if x != out_h or y != out_w:
                pred = zoom(out, (x / out_h, y / out_w), order=0)
            else:
                pred = out
            prediction[ind] = pred

    metric_list = []
    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(
            prediction == i, label == i))
    return metric_list


def test_single_volume_scm(image, label, net1, net2, scm, classes, multimask_output=True, patch_size=[512, 512]):
    image, label = image.squeeze(0).cpu().detach(
    ).numpy(), label.squeeze(0).cpu().detach().numpy()
    prediction = np.zeros_like(label)

    for ind in range(image.shape[0]):

        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        inputs = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)

        net1.eval()
        net2.eval()
        scm.eval()

        with torch.no_grad():

            outputs1 = net1(inputs, multimask_output, patch_size[0])
            output_masks1 = outputs1['masks']
            output1 = torch.softmax(output_masks1, dim=1)

            outputs2 = net2(inputs, multimask_output, patch_size[0])
            output_masks2 = outputs2['masks']
            output2 = torch.softmax(output_masks2, dim=1)

            conv_in = torch.cat([output1, output2], dim=1)
            conv_out = scm(conv_in)

            out = torch.argmax(torch.softmax(conv_out, dim=1), dim=1).squeeze(0)

            out = out.cpu().detach().numpy()

            out_h, out_w = out.shape
            if x != out_h or y != out_w:
                pred = zoom(out, (x / out_h, y / out_w), order=0)
            else:
                pred = out
            prediction[ind] = pred

    metric_list = []
    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(
            prediction == i, label == i))
    return metric_list