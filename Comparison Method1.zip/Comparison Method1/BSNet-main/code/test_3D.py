import glob
import shutil

from matplotlib import pyplot as plt
import argparse

from tqdm import tqdm

from metrics.metric import Metric
from models import *
from dataset import *
from utils import *
from efficientNet import *
from torchvision import transforms
import copy
import torch
from albumentations import Compose, Resize, Normalize, ColorJitter, HorizontalFlip, VerticalFlip
import SimpleITK as sitk
from medpy import metric
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default=r"D:\2024\ssr\DATA\ACDC", help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='ACDC/Uncertainty_Rectified_Pyramid_Consistency', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='unet_urpc', help='model_name')
parser.add_argument('--num_classes', type=int,  default=4,
                    help='output channel of network')
parser.add_argument('--labeled_num', type=int, default=1,
                    help='labeled data')


def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    dice = metric.binary.dc(pred, gt)
    if pred.sum() != 0:
        asd = metric.binary.asd(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
    else:
        print('bad')
        asd = -1
        hd95 = -1
    jc = metric.binary.jc(pred, gt)
    return dice, hd95, asd, jc


def test_single_volume(case, net, test_save_path, FLAGS):
    h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
    image = h5f['image'][:]
    label = h5f['label'][:]
    prediction = np.zeros_like(label)
    for ind in range(image.shape[0]):
        slice = image[ind, :, :]
        x, y = slice.shape[0], slice.shape[1]
        slice = zoom(slice, (512 / x, 512 / y), order=0)
        input = torch.from_numpy(slice).unsqueeze(
            0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():
            if FLAGS.model == "unet_urpc":
                out_main, _, _, _ = net(input)
            else:
                out_main = net(input)
            out = torch.argmax(torch.softmax(
                out_main, dim=1), dim=1).squeeze(0)
            out = out.cpu().detach().numpy()
            pred = zoom(out, (x / 512, y / 512), order=0)
            prediction[ind] = pred

    first_metric = calculate_metric_percase(prediction == 1, label == 1)
    second_metric = calculate_metric_percase(prediction == 2, label == 2)
    third_metric = calculate_metric_percase(prediction == 3, label == 3)

    img_itk = sitk.GetImageFromArray(image.astype(np.float32))
    img_itk.SetSpacing((1, 1, 10))
    prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
    prd_itk.SetSpacing((1, 1, 10))
    lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
    lab_itk.SetSpacing((1, 1, 10))
    sitk.WriteImage(prd_itk, test_save_path + case + "_pred.nii.gz")
    sitk.WriteImage(img_itk, test_save_path + case + "_img.nii.gz")
    sitk.WriteImage(lab_itk, test_save_path + case + "_gt.nii.gz")
    return first_metric, second_metric, third_metric

# def Inference(FLAGS):
#     with open(FLAGS.root_path + '/test.list', 'r') as f:
#         image_list = f.readlines()
#     image_list = sorted([item.replace('\n', '').split(".")[0]
#                          for item in image_list])
#     snapshot_path = "../model/{}_{}_labeled/{}".format(
#         FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
#     test_save_path = "../model/{}_{}_labeled/{}_predictions/".format(
#         FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
#     if os.path.exists(test_save_path):
#         shutil.rmtree(test_save_path)
#     os.makedirs(test_save_path)
#     net = net_factory(net_type=FLAGS.model, in_chns=1,
#                       class_num=FLAGS.num_classes)
#     save_mode_path = os.path.join(
#         snapshot_path, '{}_best_model.pth'.format(FLAGS.model))
#     net.load_state_dict(torch.load(save_mode_path))
#     print("init weight from {}".format(save_mode_path))
#     net.eval()
#
#     first_total = 0.0
#     second_total = 0.0
#     third_total = 0.0
#     for case in tqdm(image_list):
#         first_metric, second_metric, third_metric = test_single_volume(
#             case, net, test_save_path, FLAGS)
#         first_total += np.asarray(first_metric)
#         second_total += np.asarray(second_metric)
#         third_total += np.asarray(third_metric)
#     avg_metric = [first_total / len(image_list), second_total /
#                   len(image_list), third_total / len(image_list)]
#     return avg_metric
def extract_ordered_overlap(image, patch_size, s):
    image_h = image.shape[2]
    image_w = image.shape[3]
    N_patches_img = ((image_h - patch_size) // s + 1) * ((image_w - patch_size) // s + 1)

    patches = torch.empty((N_patches_img, 3, patch_size, patch_size))
    # print(patches.shape)
    iter_tot = 0
    for h in range((image_h - patch_size) // s + 1):
        for w in range((image_w - patch_size) // s + 1):
            patch = image[0, :, h * s:(h * s) + patch_size, w * s:(w * s) + patch_size]
            patches[iter_tot] = patch
            iter_tot = iter_tot + 1
    return patches


def recompone_overlap(preds, img_h, img_w, s):
    # print(preds.shape)
    patch_h = preds.shape[2]
    patch_w = preds.shape[3]
    N_patches_h = (img_h - patch_h) // s + 1
    N_patches_w = (img_w - patch_w) // s + 1
    N_patches_img = N_patches_h * N_patches_w

    full_prob = torch.zeros((1, preds.shape[1], img_h, img_w)).cuda()
    full_sum = torch.zeros((1, preds.shape[1], img_h, img_w)).cuda()
    k = 0

    for h in range((img_h - patch_h) // s + 1):
        for w in range((img_w - patch_w) // s + 1):
            full_prob[:, :, h * s:(h * s) + patch_h, w * s:(w * s) + patch_w] += preds[k]
            full_sum[:, :, h * s:(h * s) + patch_h, w * s:(w * s) + patch_w] += 1
            k += 1

    final_avg = full_prob / full_sum

    return final_avg


def Inference(FLAGS):
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    num_classes = 4
    batch_size = 1
    image_size = (512, 512)
    save_dir = './result/'
    patch_size = 512
    stride = 256
    MT = 1
    base_dir = './data/drive/test/'
    dataset = 'polyp'
    with open(FLAGS.root_path + '/test.list', 'r') as f:
        image_list = f.readlines()
    image_list = sorted([item.replace('\n', '').split(".")[0]
                         for item in image_list])
    snapshot_path = "../model/{}_{}_labeled/{}".format(
        FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
    test_save_path = "../model/{}_{}_labeled/{}_predictions/".format(
        FLAGS.exp, FLAGS.labeled_num, FLAGS.model)
    if os.path.exists(test_save_path):
        shutil.rmtree(test_save_path)
    os.makedirs(test_save_path)
    # net = net_factory(net_type=FLAGS.model, in_chns=1,
    #                   class_num=FLAGS.num_classes)
    save_mode_path = os.path.join(
        snapshot_path, '{}_best_model.pth'.format(FLAGS.model))
    # net.load_state_dict(torch.load(save_mode_path))
    # print("init weight from {}".format(save_mode_path))
    # net.eval()



    metric1 = Metric(num_classes=2)
    metric2 = Metric(num_classes=2)
    if MT:

        # T_model_name = 'UAMT_teacher_drive_'  # our_resnet_teacher_skin_
        # S_model_name = 'UAMT_student_drive_'  # our_resnet_student_skin_
        T_model_name = 'teacher_'
        S_model_name = 'student_'

        T_model = resnet34(num_classes)
        S_model = copy.deepcopy(T_model)
        print(id(T_model), id(S_model))

        T_path=r"D:\2024\ssr\BSNet-main\code\code\new\ACDC\ours_student\best_model.pth"
        S_path=r"D:\2024\ssr\BSNet-main\code\code\new\ACDC\ours_teacher\best_model.pth"

        T_model.load_state_dict(torch.load(T_path))
        T_model.cuda()
        T_model.eval()
        S_model.load_state_dict(torch.load(S_path))
        S_model.cuda()
        S_model.eval()
        j = 0
        evaluator_T = Evaluator()
        evaluator_S = Evaluator()
        first_total1 = 0.0
        second_total1 = 0.0
        third_total1 = 0.0
        first_total2 = 0.0
        second_total2 = 0.0
        third_total2 = 0.0
        test_save_path = r"D:\2024\ssr\BSNet-main\ACDC\BSNet"
        if os.path.exists(test_save_path):
            shutil.rmtree(test_save_path)
        os.makedirs(test_save_path)
        for case in tqdm(image_list):
            h5f = h5py.File(FLAGS.root_path + "/data/{}.h5".format(case), 'r')
            image = h5f['image'][:]
            label = h5f['label'][:]
            prediction1 = np.zeros_like(label)
            prediction2 = np.zeros_like(label)
            for ind in range(image.shape[0]):
                slice = image[ind, :, :]
                x, y = slice.shape[0], slice.shape[1]
                slice = zoom(slice, (512 / x, 512 / y), order=0)
                input = torch.from_numpy(slice).unsqueeze(
                    0).unsqueeze(0).float().cuda()
                inputs = repeat(input, 'b c h w -> b (repeat c) h w', repeat=3)
                with torch.no_grad():
                    # images, labels = input.cuda(), label.cuda()
                    ####add######
                    # patches = extract_ordered_overlap(images, patch_size, stride)
                    # print(patches.shape)
                    predictions_T = T_model(inputs)
                    out1 = torch.argmax(torch.softmax(
                        predictions_T, dim=1), dim=1).squeeze(0)
                    # pred_T = predictions_T[:, :, :, :]
                    # pred_T = recompone_overlap(pred_T, 512, 512, stride)
                    # pred = torch.max(predictions_T, dim=1)[1]


                    predictions_S = S_model(inputs)
                    out2 = torch.argmax(torch.softmax(
                        predictions_S, dim=1), dim=1).squeeze(0)
                    out1 = out1.cpu().detach().numpy()
                    pred1 = zoom(out1, (x / 512, y / 512), order=0)
                    prediction1[ind] = pred1

                    out2 = out2.cpu().detach().numpy()
                    pred2 = zoom(out2, (x / 512, y / 512), order=0)
                    prediction2[ind] = pred2

                # 从 case 中提取患者编号和帧编号
                patient_id, frame_id = case.split("_")  # 假设 case 格式为 "patient003_frame01"

                # 构造预测结果的文件名
                pred_name = f"{patient_id}_{frame_id}_pred_{ind + 1}.png"
                pred_path = os.path.join(test_save_path, pred_name)

                # 保存预测结果
                plt.figure(figsize=(10, 10))
                plt.imshow(pred1, cmap='gray', interpolation='none')
                plt.axis('off')
                plt.savefig(pred_path, bbox_inches='tight', pad_inches=0, dpi=300, format='png')
                plt.close('all')


                first_metric1 = calculate_metric_percase(prediction1 == 1, label == 1)
                second_metric1 = calculate_metric_percase(prediction1 == 2, label == 2)
                third_metric1 = calculate_metric_percase(prediction1 == 3, label == 3)
                first_metric2 = calculate_metric_percase(prediction2 == 1, label == 1)
                second_metric2 = calculate_metric_percase(prediction2 == 2, label == 2)
                third_metric2 = calculate_metric_percase(prediction2 == 3, label == 3)
            first_total1 += np.asarray(first_metric1)
            second_total1 += np.asarray(second_metric1)
            third_total1 += np.asarray(third_metric1)

            first_total2 += np.asarray(first_metric2)
            second_total2 += np.asarray(second_metric2)
            third_total2 += np.asarray(third_metric2)
        avg_metric2 = [first_total1 / len(image_list), second_total1 /
                           len(image_list), third_total1 / len(image_list)]
        avg_metric1 = [first_total1 / len(image_list), second_total1 /
                       len(image_list), third_total1 / len(image_list)]
    return avg_metric1,avg_metric2
                # pred_S = predictions_S[:, :, :, :]
                # pred_S = recompone_overlap(pred_S, 512, 512, stride)
                # evaluator_S.update(pred_S, labels[0, :, :].float())


                # _, axs = plt.subplots(1, 2, figsize=(25, 25))
                # axs[0].imshow(pred.cpu().permute(1, 2, 0).detach().numpy())
                # axs[1].imshow(labels.cpu().permute(1, 2, 0).detach().numpy())
                # plt.subplots_adjust(wspace=0.01, hspace=0)
                # filename = f"./BSNet{i + 1}.png"
                # plt.savefig(filename, bbox_inches="tight", dpi=300)
                # plt.close('all')
        #
        # evaluator_T.show()
        # evaluator_S.show()

    #
    # else:
    #
    #     model_name = 'URPC_drive_'  # URPC_drive_
    #     model = resnet34(num_classes)
    #
    #     for k in range(300, 303, 3):
    #         print('./new/' + model_name + str(k) + '.pth')
    #         model.load_state_dict(torch.load('./new/' + model_name + str(k) + '.pth'))
    #         model.cuda()
    #         model.eval()
    #         j = 0
    #         evaluator = Evaluator()
    #         with torch.no_grad():
    #             for sampled_batch in dataloader:
    #                 images, labels = sampled_batch['image'], sampled_batch['label']
    #                 images, labels = images.cuda(), labels.cuda()
    #                 patches = extract_ordered_overlap(images, patch_size, stride)
    #                 # print(patches.shape)
    #                 # outputs_tanh, predictions = model(patches.cuda())
    #                 predictions, _, _, _ = model(patches.cuda())
    #                 # predictions = model(patches.cuda())
    #                 # print(predictions.shape)
    #                 pred = predictions[:, 1, :, :]
    #                 pred = recompone_overlap(pred, 512, 512, stride)
    #
    #                 # print(pred.shape)
    #                 evaluator.update(pred, labels[0, :, :].float())
    #
    #                 for i in range(batch_size):
    #                     labels = labels.cpu().numpy()
    #                     label = (labels[i] * 255)
    #                     pred = pred.cpu().numpy()
    #                     # total_img = np.concatenate((label,pred[:,:]*255),axis=1)
    #                     cv2.imwrite(save_dir + 'GT_Pre' + str(j) + '.jpg', pred[:, :] * 255)
    #                     j = j + 1
    #         evaluator.show()
    # iou = np.nanmean(metric1.evaluate()["iou"][1:].numpy())
    # print("iou:{}".format(iou.item()))
    # dice = np.nanmean(metric1.evaluate()["dice"][1:].numpy())
    # print("dice:{}".format(dice.item()))
    # se = np.nanmean(metric1.evaluate()["se"][1:].numpy())
    # print("se:{}".format(se.item()))
    # sp = np.nanmean(metric1.evaluate()["specifity"][1:].numpy())
    # print("specifity:{}".format(sp.item()))
    # acc = np.nanmean(metric1.evaluate()["acc"][1:].numpy())
    # print("acc:{}".format(acc.item()))


if __name__ == '__main__':
    FLAGS = parser.parse_args()
    metric1,metric2= Inference(FLAGS)
    print(metric1)
    print((metric1[0]+metric1[1]+metric1[2])/3)
    print(metric2)
    print((metric2[0] + metric2[1] + metric2[2]) / 3)